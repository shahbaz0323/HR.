"""Auto-generated: all HTML templates embedded as strings (no templates/ folder needed).
This lets the whole app ship as just 2-3 files for easy mobile upload to GitHub."""

TEMPLATES = {
    "base.html": """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{% block title %}HR System{% endblock %}</title>

<link rel="manifest" href="/manifest.json">
<meta name="theme-color" content="#10265c">
<link rel="apple-touch-icon" href="/icon-192.png">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="HR System">
<script>
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch(() => {});
  });
}
</script>

<style>
* { box-sizing: border-box; }
body {
    margin: 0;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
    background: #f4f6f8;
    color: #1f2d3d;
}

/* ---------- Layout ---------- */
.layout { display: flex; min-height: 100vh; }
.sidebar {
    width: 230px;
    background: #10265c;
    color: #fff;
    display: flex;
    flex-direction: column;
    padding: 20px 0;
    flex-shrink: 0;
}
.brand { font-size: 20px; font-weight: 700; padding: 0 20px 20px; border-bottom: 1px solid #24408f; margin-bottom: 10px;}
.sidebar nav { display: flex; flex-direction: column; flex: 1; }
.sidebar nav a {
    color: #c9d3de;
    text-decoration: none;
    padding: 12px 20px;
    font-size: 14px;
}
.sidebar nav a:hover, .sidebar nav a.active { background: #163a8e; color: #fff; border-left: 3px solid #5b8def; }
.sidebar-footer { padding: 15px 20px; border-top: 1px solid #24408f; font-size: 13px; }
.sidebar-footer a { display: block; color: #9fb0c3; text-decoration: none; margin-top: 8px; }
.sidebar-footer a:hover { color: #fff; }
.user-chip { font-weight: 600; margin-bottom: 4px; }
.role-badge { background: #3a6fd8; color: #072742; font-size: 11px; padding: 2px 6px; border-radius: 4px; margin-left: 4px; }

.content { flex: 1; padding: 28px 34px; max-width: 1300px; }

/* ---------- Cards / Panels ---------- */
.panel {
    background: #fff;
    border-radius: 10px;
    padding: 22px;
    margin-bottom: 22px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.08);
}
.panel h2 { margin-top: 0; font-size: 18px; color: #1f2d3d; }
.page-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
.page-header h1 { font-size: 24px; margin: 0; }

/* ---------- Stat cards ---------- */
.stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-bottom: 24px; }
.stat-card { background: #fff; border-radius: 10px; padding: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.08); border-left: 4px solid #3a6fd8; }
.stat-card .num { font-size: 28px; font-weight: 700; color: #1f2d3d; }
.stat-card .label { font-size: 13px; color: #6b7c93; margin-top: 4px; }

/* ---------- Forms ---------- */
label { display: block; font-size: 13px; font-weight: 600; margin-bottom: 5px; color: #445; }
input[type=text], input[type=password], input[type=number], input[type=date], input[type=file], select, textarea {
    width: 100%;
    padding: 9px 10px;
    border: 1px solid #d5dce4;
    border-radius: 6px;
    font-size: 14px;
    margin-bottom: 14px;
    background: #fff;
}
input:focus, select:focus, textarea:focus { outline: none; border-color: #3a6fd8; }
.form-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 0 18px; }
.btn {
    display: inline-block;
    background: #163a8e;
    color: #fff;
    border: none;
    padding: 10px 18px;
    border-radius: 6px;
    font-size: 14px;
    cursor: pointer;
    text-decoration: none;
    font-weight: 600;
}
.btn:hover { background: #0f2d72; }
.btn-secondary { background: #eef1f4; color: #1f2d3d; }
.btn-secondary:hover { background: #e0e5ea; }
.btn-danger { background: #c0392b; }
.btn-danger:hover { background: #992d22; }
.btn-sm { padding: 6px 12px; font-size: 12px; }
.btn-row { display: flex; gap: 10px; margin-top: 6px; flex-wrap: wrap; }

/* ---------- Table ---------- */
table { width: 100%; border-collapse: collapse; background: #fff; border-radius: 8px; overflow: hidden; }
th, td { text-align: left; padding: 10px 12px; font-size: 13px; border-bottom: 1px solid #eef1f4; }
th { background: #f4f6f8; font-weight: 700; color: #445; }
tr:hover td { background: #fafbfc; }
.table-wrap { overflow-x: auto; }

/* ---------- Badges ---------- */
.badge { display: inline-block; padding: 3px 10px; border-radius: 12px; font-size: 11px; font-weight: 700; }
.badge-active, .badge-present, .badge-hired, .badge-approved { background: #e3f7e9; color: #1e8e3e; }
.badge-left, .badge-absent, .badge-rejected { background: #fdecea; color: #c0392b; }
.badge-leave, .badge-pending, .badge-applied { background: #fff4e0; color: #b8860b; }
.badge-shortlisted, .badge-interviewed { background: #e8f0fe; color: #1a5fb4; }

/* ---------- Flash ---------- */
.flash { padding: 12px 16px; border-radius: 6px; margin-bottom: 16px; font-size: 14px; }
.flash-success { background: #e3f7e9; color: #1e8e3e; }
.flash-error { background: #fdecea; color: #c0392b; }

/* ---------- Login page ---------- */
.login-wrap {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    min-height: 100vh;
    background: linear-gradient(160deg, #eef3fb 0%, #dce6f7 45%, #cfdcf3 100%);
    padding: 30px 16px;
}
.login-card {
    background: #fff;
    padding: 40px 34px 30px;
    border-radius: 22px;
    width: 100%;
    max-width: 400px;
    box-shadow: 0 20px 50px rgba(21, 58, 139, 0.15);
    text-align: center;
}
.login-logo { position: relative; display: inline-block; margin-bottom: 6px; }
.login-hr-text {
    font-size: 26px;
    font-weight: 800;
    color: #0f2d6b;
    letter-spacing: 1px;
    margin-top: -6px;
}
.login-card h1 { font-size: 21px; margin: 6px 0 2px; color: #10265c; font-weight: 800; }
.login-card p.sub { text-align: center; color: #6b7c93; font-size: 13px; margin-bottom: 26px; }

.input-icon-wrap { position: relative; margin-bottom: 16px; }
.input-icon-wrap input {
    padding: 13px 40px 13px 42px;
    border-radius: 12px;
    background: #f5f7fb;
    border: 1px solid #e3e8f0;
    margin-bottom: 0;
    font-size: 14px;
}
.input-icon-wrap input:focus { background: #fff; border-color: #3a6fd8; }
.input-icon { position: absolute; left: 13px; top: 50%; transform: translateY(-50%); }
.input-icon-right { position: absolute; right: 13px; top: 50%; transform: translateY(-50%); cursor: pointer; }

.login-row { display: flex; justify-content: space-between; align-items: center; margin: 4px 0 20px; }
.checkbox-label { display: flex; align-items: center; gap: 6px; font-size: 13px; color: #445; font-weight: 500; margin: 0; }
.checkbox-label input { width: auto; margin: 0; }
.forgot-link { font-size: 12px; color: #1849c4; text-decoration: none; font-weight: 600; }
.forgot-link:hover { text-decoration: underline; }
.forgot-username-row { font-size: 12px; color: #6b7c93; margin-top: 14px; }
.forgot-username-row a { color: #1849c4; font-weight: 600; text-decoration: none; }
.forgot-username-row a:hover { text-decoration: underline; }

.login-btn {
    width: 100%;
    background: linear-gradient(135deg, #1849c4, #0f2d8b);
    padding: 14px;
    border-radius: 12px;
    font-size: 15px;
    letter-spacing: 0.5px;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    box-shadow: 0 8px 20px rgba(24, 73, 196, 0.35);
}
.login-btn:hover { background: linear-gradient(135deg, #143da8, #0c2470); }
.login-btn .arrow { font-size: 16px; }

.login-features {
    display: flex;
    justify-content: space-between;
    margin-top: 28px;
    padding-top: 20px;
    border-top: 1px solid #eef1f6;
    gap: 6px;
}
.login-features div { flex: 1; font-size: 11px; color: #6b7c93; }
.login-features b { display: block; font-size: 12px; color: #10265c; margin: 4px 0 2px; }
.login-features small { font-size: 10px; line-height: 1.3; display: block; }
.feat-icon { font-size: 20px; }

.login-version { margin-top: 18px; font-size: 12px; color: #7c8aa0; }

/* ---------- PWA Install Button ---------- */
.pwa-install-btn {
    position: fixed;
    bottom: 20px;
    right: 20px;
    z-index: 999;
    background: linear-gradient(135deg, #1849c4, #0f2d8b);
    color: #fff;
    border: none;
    padding: 12px 20px;
    border-radius: 30px;
    font-size: 14px;
    font-weight: 700;
    box-shadow: 0 8px 24px rgba(15, 45, 139, 0.4);
    cursor: pointer;
}
.pwa-install-btn:hover { background: linear-gradient(135deg, #143da8, #0c2470); }

/* ---------- Personal file view ---------- */
.info-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 10px 24px; }
.info-grid div span.k { display: block; font-size: 12px; color: #8b98a8; }
.info-grid div span.v { font-size: 14px; font-weight: 600; }
.photo-box { display: inline-block; text-align: center; }
.photo-box img { width: 120px; height: 140px; object-fit: cover; border-radius: 8px; border: 1px solid #d5dce4; cursor: zoom-in; }
.nic-item { display: inline-block; text-align: center; margin-right: 14px; margin-bottom: 14px; }
.nic-box { width: 220px; border-radius: 8px; border: 1px solid #d5dce4; display: block; cursor: zoom-in; }
.img-caption { font-size: 11px; color: #6b7c93; margin-top: 6px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.3px; }

/* ---------- Mobile Responsive ---------- */
@media (max-width: 820px) {
    .layout { flex-direction: column; }
    .sidebar {
        width: 100%;
        flex-direction: row;
        align-items: center;
        padding: 10px 12px;
        flex-wrap: wrap;
        position: sticky;
        top: 0;
        z-index: 50;
    }
    .brand { padding: 0 12px 0 0; border-bottom: none; margin-bottom: 0; font-size: 16px; }
    .sidebar nav { flex-direction: row; flex-wrap: wrap; flex: 1; }
    .sidebar nav a { padding: 8px 10px; font-size: 12px; }
    .sidebar nav a:hover, .sidebar nav a.active { border-left: none; border-bottom: 2px solid #3a6fd8; }
    .sidebar-footer { border-top: none; padding: 6px 10px; display: flex; align-items: center; gap: 10px; font-size: 12px; }
    .sidebar-footer a { display: inline; margin-top: 0; }
    .user-chip { margin-bottom: 0; }
    .content { padding: 16px; }
    .page-header { flex-direction: column; align-items: flex-start; gap: 10px; }
    .form-grid { grid-template-columns: 1fr; }
    .stats-grid { grid-template-columns: repeat(2, 1fr); }
    table { font-size: 12px; }
    th, td { padding: 8px 6px; }
    .login-card { width: 100%; max-width: 340px; padding: 30px 22px; }
}

@media (max-width: 480px) {
    .stats-grid { grid-template-columns: 1fr; }
    .photo-box img { width: 90px; height: 105px; }
    .nic-box img { width: 100%; margin-right: 0; margin-bottom: 10px; }
}

</style>
</head>
<body>
{% if session.get('user_id') %}
<div class="layout">
  <aside class="sidebar">
    <div class="brand">HR System</div>
    <nav>
      <a href="{{ url_for('dashboard') }}" class="{{ 'active' if request.endpoint=='dashboard' }}">Dashboard</a>
      <a href="{{ url_for('employees_list') }}" class="{{ 'active' if request.endpoint and request.endpoint.startswith('employee') }}">Employees</a>
      <a href="{{ url_for('attendance_page') }}" class="{{ 'active' if request.endpoint=='attendance_page' }}">Attendance</a>
      <a href="{{ url_for('roster_page') }}" class="{{ 'active' if request.endpoint=='roster_page' }}">Roster</a>
      <a href="{{ url_for('payroll_page') }}" class="{{ 'active' if request.endpoint=='payroll_page' }}">Payroll</a>
      <a href="{{ url_for('departments_page') }}" class="{{ 'active' if request.endpoint=='departments_page' }}">Departments</a>
      <a href="{{ url_for('recruitment_page') }}" class="{{ 'active' if request.endpoint and request.endpoint.startswith('recruitment') }}">Recruitment</a>
      <a href="{{ url_for('ai_assistant_page') }}" class="{{ 'active' if request.endpoint=='ai_assistant_page' }}">AI Assistant</a>
      {% if session.get('role') == 'Admin' %}
      <a href="{{ url_for('users_page') }}" class="{{ 'active' if request.endpoint and request.endpoint.startswith('user') }}">Manage Users</a>
      {% endif %}
    </nav>
    <div class="sidebar-footer">
      <div class="user-chip">{{ current_username }} <span class="role-badge">{{ current_role }}</span></div>
      <a href="{{ url_for('change_password') }}">Change Password</a>
      <a href="{{ url_for('logout') }}">Logout</a>
    </div>
  </aside>
  <main class="content">
    {% with messages = get_flashed_messages(with_categories=true) %}
      {% if messages %}
        {% for category, message in messages %}
          <div class="flash flash-{{ category }}">{{ message }}</div>
        {% endfor %}
      {% endif %}
    {% endwith %}
    {% block content %}{% endblock %}
  </main>
</div>
{% else %}
  {% with messages = get_flashed_messages(with_categories=true) %}
    {% if messages %}
      {% for category, message in messages %}
        <div class="flash flash-{{ category }}">{{ message }}</div>
      {% endfor %}
    {% endif %}
  {% endwith %}
  {% block content_noauth %}{% endblock %}
{% endif %}

<button id="pwaInstallBtn" class="pwa-install-btn" style="display:none;">📲 Install App</button>
<script>
let deferredInstallPrompt = null;
const installBtn = document.getElementById('pwaInstallBtn');
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredInstallPrompt = e;
  if (installBtn) installBtn.style.display = 'block';
});
if (installBtn) {
  installBtn.addEventListener('click', async () => {
    if (!deferredInstallPrompt) return;
    deferredInstallPrompt.prompt();
    await deferredInstallPrompt.userChoice;
    deferredInstallPrompt = null;
    installBtn.style.display = 'none';
  });
}
window.addEventListener('appinstalled', () => {
  if (installBtn) installBtn.style.display = 'none';
});

// Photo/NIC image lightbox - click any .photo-box img or .nic-box to view full size
document.addEventListener('click', function(e) {
  const img = e.target.closest('.photo-box img, img.nic-box');
  if (img) {
    const overlay = document.getElementById('imgLightbox');
    const overlayImg = document.getElementById('imgLightboxImg');
    overlayImg.src = img.src;
    overlay.style.display = 'flex';
  }
});
function closeLightbox() {
  document.getElementById('imgLightbox').style.display = 'none';
}
</script>

<div id="imgLightbox" onclick="closeLightbox()" style="display:none; position:fixed; inset:0; background:rgba(10,15,25,0.88); z-index:999; align-items:center; justify-content:center; padding:20px; cursor:zoom-out;">
  <img id="imgLightboxImg" src="" style="max-width:92vw; max-height:88vh; border-radius:10px; box-shadow:0 20px 60px rgba(0,0,0,0.5);">
</div>
</body>
</html>
""",

    "ai_assistant.html": """{% extends "base.html" %}
{% block title %}AI Assistant{% endblock %}
{% block content %}
<div class="page-header"><h1>AI Assistant</h1></div>

<div class="panel">
  <h2>Employee / Attendance Data Ke Baray Mein Poochein</h2>
  <p style="font-size:13px;color:#6b7c93;">
    Misal: "Ali Raza ka is mahine attendance kaisa raha?" ya "Production department mein kitne employees hain?"
    ya "Kis employee ki salary sab se zyada barhi hai?"
  </p>
  <form method="POST">
    <textarea name="question" rows="3" placeholder="Apna sawal yahan likhein..." required>{{ question or '' }}</textarea>
    <button type="submit" class="btn">Poochein</button>
  </form>
</div>

{% if error %}
<div class="panel">
  <div class="flash flash-error">{{ error }}</div>
</div>
{% endif %}

{% if answer %}
<div class="panel">
  <h2>Jawab</h2>
  <p style="white-space:pre-wrap; line-height:1.6;">{{ answer }}</p>
</div>
{% endif %}
{% endblock %}
""",

    "attendance.html": """{% extends "base.html" %}
{% block title %}Attendance{% endblock %}
{% block content %}
<div class="page-header"><h1>Attendance</h1></div>

<div class="panel">
  <h2>Mark Daily Attendance</h2>
  <form method="POST">
    <div class="form-grid">
      <div><label>Employee</label>
        <select name="employee_id" required>
          <option value="">-- Select Employee --</option>
          {% for e in employees %}<option value="{{ e['id'] }}">{{ e['name'] }}</option>{% endfor %}
        </select>
      </div>
      <div><label>Date</label><input type="date" name="date" value="{{ today }}" required></div>
      <div><label>Status</label>
        <select name="status">
          <option value="Present">Present</option>
          <option value="Absent">Absent</option>
          <option value="Leave">Leave</option>
        </select>
      </div>
      <div><label>Overtime (hrs)</label><input type="number" step="0.5" name="overtime_hours" value="0"></div>
    </div>
    <button type="submit" class="btn">Mark Attendance</button>
  </form>
</div>

<div class="panel">
  <h2>Attendance Records</h2>
  <form method="GET" class="form-grid" style="margin-bottom:10px;">
    <div><label>Filter: Employee</label>
      <select name="employee_id">
        <option value="">-- All --</option>
        {% for e in employees %}<option value="{{ e['id'] }}" {{ 'selected' if emp_filter==e['id']|string }}>{{ e['name'] }}</option>{% endfor %}
      </select>
    </div>
    <div><label>Month</label><input type="month" name="month" value="{{ month_filter }}"></div>
    <div style="align-self:end;"><button type="submit" class="btn btn-secondary">View</button></div>
    <div style="align-self:end;">
      {% if emp_filter %}
      <a href="{{ url_for('pdf_attendance_report', employee_id=emp_filter, month=month_filter) }}" target="_blank" class="btn">Print Report (PDF)</a>
      {% endif %}
    </div>
    <div style="align-self:end;">
      <a href="{{ url_for('export_attendance_excel', employee_id=emp_filter, month=month_filter) }}" class="btn btn-secondary">Export to Excel</a>
    </div>
  </form>

  <div class="table-wrap">
  <table>
    <tr><th>Employee</th><th>Date</th><th>Status</th><th>Overtime (hrs)</th><th>Marked By</th></tr>
    {% for r in rows %}
    <tr>
      <td>{{ r['emp_name'] }}</td><td>{{ r['date'] }}</td>
      <td><span class="badge badge-{{ r['status']|lower }}">{{ r['status'] }}</span></td>
      <td>{{ r['overtime_hours'] }}</td><td>{{ r['marked_by'] or '-' }}</td>
    </tr>
    {% else %}
    <tr><td colspan="5">Koi record nahi mila.</td></tr>
    {% endfor %}
  </table>
  </div>
</div>
{% endblock %}
""",

    "change_password.html": """{% extends "base.html" %}
{% block title %}Change Password{% endblock %}
{% block content %}
<div class="page-header"><h1>Change Password</h1></div>
<div class="panel" style="max-width:400px;">
  <form method="POST">
    <label>Current Password</label>
    <input type="password" name="current_password" required>
    <label>New Password</label>
    <input type="password" name="new_password" required>
    <button type="submit" class="btn">Update Password</button>
  </form>
</div>
{% endblock %}
""",

    "dashboard.html": """{% extends "base.html" %}
{% block title %}Dashboard{% endblock %}
{% block content %}
<div class="page-header"><h1>Dashboard</h1></div>

<div class="stats-grid">
  <div class="stat-card"><div class="num">{{ total_employees }}</div><div class="label">Active Employees</div></div>
  <div class="stat-card"><div class="num">{{ total_left }}</div><div class="label">Left / Resigned</div></div>
  <div class="stat-card"><div class="num">{{ today_present }}</div><div class="label">Present Today</div></div>
  <div class="stat-card"><div class="num">{{ pending_candidates }}</div><div class="label">Candidates in Pipeline</div></div>
</div>

<div class="panel">
  <h2>Recently Added Employees</h2>
  <div class="table-wrap">
  <table>
    <tr><th>Name</th><th>Department</th><th>Designation</th><th>Status</th><th></th></tr>
    {% for e in recent_employees %}
    <tr>
      <td>{{ e['name'] }}</td>
      <td>{{ e['department'] or '-' }}</td>
      <td>{{ e['designation'] or '-' }}</td>
      <td><span class="badge badge-{{ e['status']|lower }}">{{ e['status'] }}</span></td>
      <td><a href="{{ url_for('employee_view', emp_id=e['id']) }}" class="btn btn-sm btn-secondary">View</a></td>
    </tr>
    {% else %}
    <tr><td colspan="5">Abhi tak koi employee add nahi hua.</td></tr>
    {% endfor %}
  </table>
  </div>
</div>
{% endblock %}
""",

    "departments.html": """{% extends "base.html" %}
{% block title %}Departments{% endblock %}
{% block content %}
<div class="page-header"><h1>Departments</h1></div>

<div class="panel">
  <h2>Add Department</h2>
  <form method="POST" style="display:flex; gap:10px; align-items:end;">
    <div style="flex:1;"><label>Department Name</label><input type="text" name="name" required placeholder="e.g. Production, HR, Accounts"></div>
    <button type="submit" class="btn" style="margin-bottom:14px;">Add</button>
  </form>
</div>

<div class="panel">
  <h2>Existing Departments</h2>
  <div class="table-wrap">
  <table>
    <tr><th>Department</th><th>Active Employees</th><th></th></tr>
    {% for d in departments %}
    <tr>
      <td>{{ d['name'] }}</td>
      <td>{{ d['emp_count'] }}</td>
      <td>
        <form method="POST" action="{{ url_for('department_delete', dept_id=d['id']) }}" onsubmit="return confirm('Delete this department?');" style="display:inline;">
          <button type="submit" class="btn btn-sm btn-danger">Delete</button>
        </form>
      </td>
    </tr>
    {% else %}
    <tr><td colspan="3">Koi department nahi mila. Upar se add karein.</td></tr>
    {% endfor %}
  </table>
  </div>
</div>
{% endblock %}
""",

    "employee_form.html": """{% extends "base.html" %}
{% block title %}{{ 'Edit' if employee else 'Add' }} Employee{% endblock %}
{% block content %}
<div class="page-header">
  <h1>{{ 'Edit' if employee else 'Add' }} Employee</h1>
  <a href="{{ url_for('employees_list') }}" class="btn btn-secondary">Back to List</a>
</div>

<div class="panel">
  <form method="POST" enctype="multipart/form-data">
    <h2>Personal & Employment Details</h2>
    <div class="form-grid">
      <div><label>Employee Code</label><input type="text" name="emp_code" value="{{ employee['emp_code'] if employee else '' }}"></div>
      <div><label>Name *</label><input type="text" name="name" required value="{{ employee['name'] if employee else '' }}"></div>
      <div><label>Father Name</label><input type="text" name="father_name" value="{{ employee['father_name'] if employee else '' }}"></div>
      <div><label>Date of Birth</label><input type="date" name="dob" value="{{ employee['dob'] if employee else '' }}"></div>

      <div><label>Marital Status</label>
        <select name="marital_status">
          <option value="">-- Select --</option>
          <option value="Single" {{ 'selected' if employee and employee['marital_status']=='Single' }}>Single</option>
          <option value="Married" {{ 'selected' if employee and employee['marital_status']=='Married' }}>Married</option>
        </select>
      </div>
      <div><label>NIC Number</label><input type="text" name="nic_number" placeholder="XXXXX-XXXXXXX-X" value="{{ employee['nic_number'] if employee else '' }}"></div>
      <div><label>Contact</label><input type="text" name="contact" value="{{ employee['contact'] if employee else '' }}"></div>
      <div><label>Address</label><input type="text" name="address" value="{{ employee['address'] if employee else '' }}"></div>

      <div><label>Company</label><input type="text" name="company" value="{{ employee['company'] if employee else '' }}"></div>
      <div><label>Department</label>
        <select name="department">
          <option value="">-- Select Department --</option>
          {% for d in departments %}
          <option value="{{ d['name'] }}" {{ 'selected' if employee and employee['department']==d['name'] }}>{{ d['name'] }}</option>
          {% endfor %}
        </select>
      </div>
      <div><label>Designation</label><input type="text" name="designation" value="{{ employee['designation'] if employee else '' }}"></div>
      <div><label>Section</label>
        <select name="section">
          <option value="">-- Select --</option>
          <option value="Production" {{ 'selected' if employee and employee['section']=='Production' }}>Production</option>
          <option value="Staff" {{ 'selected' if employee and employee['section']=='Staff' }}>Staff</option>
        </select>
      </div>

      <div><label>Appointment Date</label><input type="date" name="appointment_date" value="{{ employee['appointment_date'] if employee else '' }}"></div>
      <div><label>Leave / Resignation Date</label><input type="date" name="leave_date" value="{{ employee['leave_date'] if employee else '' }}"></div>
      <div><label>Status</label>
        <select name="status">
          <option value="Active" {{ 'selected' if employee and employee['status']=='Active' }}>Active</option>
          <option value="Left" {{ 'selected' if employee and employee['status']=='Left' }}>Left</option>
        </select>
      </div>
      <div><label>Basic Salary</label><input type="number" step="0.01" name="basic_salary" value="{{ employee['basic_salary'] if employee else '' }}"></div>
    </div>

    <h2>Bank Account (for Salary Transfer)</h2>
    <div class="form-grid">
      <div><label>Bank Name</label><input type="text" name="bank_name" value="{{ employee['bank_name'] if employee else '' }}"></div>
      <div><label>Account Title</label><input type="text" name="bank_account_title" value="{{ employee['bank_account_title'] if employee else '' }}"></div>
      <div><label>Account Number</label><input type="text" name="bank_account_number" value="{{ employee['bank_account_number'] if employee else '' }}"></div>
      <div><label>IBAN</label><input type="text" name="bank_iban" placeholder="PKXX XXXX XXXX XXXX XXXX XXXX" value="{{ employee['bank_iban'] if employee else '' }}"></div>
    </div>

    <h2>Documents</h2>
    <div class="form-grid">
      <div><label>Photo</label><input type="file" name="photo" accept="image/*"></div>
      <div><label>NIC Front</label><input type="file" name="nic_front" accept="image/*"></div>
      <div><label>NIC Back</label><input type="file" name="nic_back" accept="image/*"></div>
    </div>
    {% if employee %}
    <p style="font-size:12px;color:#8b98a8;">Naye file select na karein agar purani hi rehne deni hai.</p>
    {% endif %}

    <div class="btn-row">
      <button type="submit" class="btn">{{ 'Update' if employee else 'Add' }} Employee</button>
      <a href="{{ url_for('employees_list') }}" class="btn btn-secondary">Cancel</a>
    </div>
  </form>
</div>
{% endblock %}
""",

    "employee_view.html": """{% extends "base.html" %}
{% block title %}{{ emp['name'] }} - Personal File{% endblock %}
{% block content %}
<div class="page-header">
  <h1>{{ emp['name'] }}</h1>
  <div class="btn-row">
    <a href="{{ url_for('employee_edit', emp_id=emp['id']) }}" class="btn btn-secondary">Edit</a>
    <a href="{{ url_for('salary_increment', emp_id=emp['id']) }}" class="btn btn-secondary">Salary Increment</a>
    <form method="POST" action="{{ url_for('employee_delete', emp_id=emp['id']) }}" onsubmit="return confirm('Delete this employee and all related records?');" style="display:inline;">
      <button type="submit" class="btn btn-danger">Delete</button>
    </form>
  </div>
</div>

<div class="panel">
  <h2>Documents</h2>
  <p style="font-size:12px;color:#8b98a8;margin-top:-8px;">PDF (print ke liye) ya Word (edit karne ke liye) — dono formats available hain.</p>
  <div class="btn-row">
    <a href="{{ url_for('pdf_appointment_letter', emp_id=emp['id']) }}" target="_blank" class="btn">Appointment Letter (PDF)</a>
    <a href="{{ url_for('word_appointment_letter', emp_id=emp['id']) }}" class="btn btn-secondary">Appointment Letter (Word)</a>
  </div>
  <div class="btn-row" style="margin-top:8px;">
    <a href="{{ url_for('pdf_taaruf_nama', emp_id=emp['id']) }}" target="_blank" class="btn">Taaruf Nama (PDF)</a>
  </div>
  <div class="btn-row" style="margin-top:8px;">
    <a href="{{ url_for('pdf_personal_file', emp_id=emp['id']) }}" target="_blank" class="btn">Full Personal File (PDF)</a>
    <a href="{{ url_for('word_personal_file', emp_id=emp['id']) }}" class="btn btn-secondary">Full Personal File (Word)</a>
  </div>
</div>

<div class="panel">
  <h2>Personal & Employment Details</h2>
  <div style="display:flex; gap:24px; flex-wrap:wrap;">
    {% if emp['photo_path'] %}
    <div class="photo-box"><img src="{{ url_for('serve_upload', filename=emp['photo_path']) }}"><div class="img-caption">Employee Photo</div></div>
    {% endif %}
    <div class="info-grid" style="flex:1;">
      <div><span class="k">Employee Code</span><span class="v">{{ emp['emp_code'] or '-' }}</span></div>
      <div><span class="k">Father Name</span><span class="v">{{ emp['father_name'] or '-' }}</span></div>
      <div><span class="k">Date of Birth</span><span class="v">{{ emp['dob'] or '-' }} ({{ age }} yrs)</span></div>
      <div><span class="k">Marital Status</span><span class="v">{{ emp['marital_status'] or '-' }}</span></div>
      <div><span class="k">NIC Number</span><span class="v">{{ emp['nic_number'] or '-' }}</span></div>
      <div><span class="k">Contact</span><span class="v">{{ emp['contact'] or '-' }}</span></div>
      <div><span class="k">Address</span><span class="v">{{ emp['address'] or '-' }}</span></div>
      <div><span class="k">Company</span><span class="v">{{ emp['company'] or '-' }}</span></div>
      <div><span class="k">Department</span><span class="v">{{ emp['department'] or '-' }}</span></div>
      <div><span class="k">Designation</span><span class="v">{{ emp['designation'] or '-' }}</span></div>
      <div><span class="k">Section</span><span class="v">{{ emp['section'] or '-' }}</span></div>
      <div><span class="k">Appointment Date</span><span class="v">{{ emp['appointment_date'] or '-' }}</span></div>
      <div><span class="k">Leave Date</span><span class="v">{{ emp['leave_date'] or '-' }}</span></div>
      <div><span class="k">Status</span><span class="v"><span class="badge badge-{{ emp['status']|lower }}">{{ emp['status'] }}</span></span></div>
      <div><span class="k">Basic Salary</span><span class="v">{{ '{:,.2f}'.format(emp['basic_salary']) if emp['basic_salary'] else '-' }}</span></div>
    </div>
  </div>
</div>

<div class="panel">
  <h2>Bank Account (Salary Transfer)</h2>
  <div class="info-grid">
    <div><span class="k">Bank Name</span><span class="v">{{ emp['bank_name'] or '-' }}</span></div>
    <div><span class="k">Account Title</span><span class="v">{{ emp['bank_account_title'] or '-' }}</span></div>
    <div><span class="k">Account Number</span><span class="v">{{ emp['bank_account_number'] or '-' }}</span></div>
    <div><span class="k">IBAN</span><span class="v">{{ emp['bank_iban'] or '-' }}</span></div>
  </div>
</div>

<div class="panel">
  <h2>NIC Images</h2>
  {% if emp['nic_front_path'] or emp['nic_back_path'] %}
    {% if emp['nic_front_path'] %}<div class="nic-item"><img class="nic-box" src="{{ url_for('serve_upload', filename=emp['nic_front_path']) }}"><div class="img-caption">NIC Front</div></div>{% endif %}
    {% if emp['nic_back_path'] %}<div class="nic-item"><img class="nic-box" src="{{ url_for('serve_upload', filename=emp['nic_back_path']) }}"><div class="img-caption">NIC Back</div></div>{% endif %}
  {% else %}
    <p>NIC images upload nahi hui.</p>
  {% endif %}
</div>

<div class="panel">
  <h2>Recent Attendance</h2>
  <div class="table-wrap">
  <table>
    <tr><th>Date</th><th>Status</th><th>Overtime (hrs)</th></tr>
    {% for a in attendance_rows %}
    <tr><td>{{ a['date'] }}</td><td><span class="badge badge-{{ a['status']|lower }}">{{ a['status'] }}</span></td><td>{{ a['overtime_hours'] }}</td></tr>
    {% else %}
    <tr><td colspan="3">Koi attendance record nahi.</td></tr>
    {% endfor %}
  </table>
  </div>
</div>

<div class="panel">
  <h2>Payroll History</h2>
  <div class="table-wrap">
  <table>
    <tr><th>Month</th><th>Present</th><th>Absent</th><th>OT hrs</th><th>Gross</th><th>Deductions</th><th>Net Salary</th><th></th></tr>
    {% for p in payroll_rows %}
    <tr>
      <td>{{ p['month'] }}</td><td>{{ p['present_days'] }}</td><td>{{ p['absent_days'] }}</td>
      <td>{{ p['overtime_hours'] }}</td><td>{{ '{:,.2f}'.format(p['gross_salary']) }}</td>
      <td>{{ '{:,.2f}'.format(p['deductions']) }}</td><td>{{ '{:,.2f}'.format(p['net_salary']) }}</td>
      <td><a href="{{ url_for('pdf_payslip', payroll_id=p['id']) }}" target="_blank" class="btn btn-sm btn-secondary">Payslip</a></td>
    </tr>
    {% else %}
    <tr><td colspan="8">Koi payroll record nahi.</td></tr>
    {% endfor %}
  </table>
  </div>
</div>
{% endblock %}
""",

    "employees_import.html": """{% extends "base.html" %}
{% block title %}Import Employees{% endblock %}
{% block content %}
<div class="page-header">
  <h1>Import Employees from Excel</h1>
  <a href="{{ url_for('employees_list') }}" class="btn btn-secondary">Back to List</a>
</div>

<div class="panel">
  <h2>Step 1: Template Download Karein</h2>
  <p style="font-size:13px;color:#6b7c93;">Ye template Excel file mein sahi column headers hain — usi format mein apna data bharein.</p>
  <a href="{{ url_for('export_employee_import_template') }}" class="btn btn-secondary">Download Template (.xlsx)</a>
</div>

<div class="panel">
  <h2>Step 2: Bhari Hui Excel File Upload Karein</h2>
  <form method="POST" enctype="multipart/form-data">
    <input type="file" name="excel_file" accept=".xlsx,.xls" required>
    <button type="submit" class="btn">Import Employees</button>
  </form>
  <p style="font-size:12px;color:#8b98a8;">Naye employees add ho jayenge (existing records overwrite nahi hote — duplicate check nahi hai, isliye ek file dobara upload na karein).</p>
</div>
{% endblock %}
""",

    "employees_list.html": """{% extends "base.html" %}
{% block title %}Employees{% endblock %}
{% block content %}
<div class="page-header">
  <h1>Employees</h1>
  <div class="btn-row">
    <a href="{{ url_for('employee_add') }}" class="btn">+ Add Employee</a>
    <a href="{{ url_for('employees_import') }}" class="btn btn-secondary">Import from Excel</a>
    <a href="{{ url_for('export_employees_excel') }}" class="btn btn-secondary">Export to Excel</a>
  </div>
</div>

<div class="panel">
  <form method="GET" style="margin-bottom:14px;">
    <input type="text" name="q" placeholder="Search by name, code, department, designation, NIC..." value="{{ q }}" style="max-width:400px;">
  </form>
  <div class="table-wrap">
  <table>
    <tr><th>Code</th><th>Name</th><th>Father Name</th><th>Department</th><th>Designation</th><th>Section</th><th>Status</th><th></th></tr>
    {% for e in employees %}
    <tr>
      <td>{{ e['emp_code'] or '-' }}</td>
      <td>{{ e['name'] }}</td>
      <td>{{ e['father_name'] or '-' }}</td>
      <td>{{ e['department'] or '-' }}</td>
      <td>{{ e['designation'] or '-' }}</td>
      <td>{{ e['section'] or '-' }}</td>
      <td><span class="badge badge-{{ e['status']|lower }}">{{ e['status'] }}</span></td>
      <td>
        <a href="{{ url_for('employee_view', emp_id=e['id']) }}" class="btn btn-sm btn-secondary">View</a>
        <a href="{{ url_for('employee_edit', emp_id=e['id']) }}" class="btn btn-sm btn-secondary">Edit</a>
      </td>
    </tr>
    {% else %}
    <tr><td colspan="8">Koi employee nahi mila.</td></tr>
    {% endfor %}
  </table>
  </div>
</div>
{% endblock %}
""",

    "forgot_password.html": """{% extends "base.html" %}
{% block title %}Forgot Password{% endblock %}
{% block content_noauth %}
<div class="login-wrap">
  <div class="login-card">
    <h1>Forgot Password</h1>
    <p class="sub">Apni registered email daalein, hum aapko reset link bhej dein ge</p>

    {% if sent %}
      <div class="flash flash-success">Agar ye email hamare system mein registered hai, to password reset link us par bhej diya gaya hai (1 hour tak valid hai).</div>
    {% endif %}
    {% if error %}
      <div class="flash flash-error">{{ error }}</div>
    {% endif %}

    {% if not sent %}
    <form method="POST">
      <div class="input-icon-wrap">
        <span class="input-icon">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><rect x="3" y="5" width="18" height="14" rx="2" stroke="#8b98a8" stroke-width="2"/><path d="M4 7l8 6 8-6" stroke="#8b98a8" stroke-width="2"/></svg>
        </span>
        <input type="email" name="email" placeholder="Your registered email" required autofocus>
      </div>
      <button class="btn login-btn" type="submit">Send Reset Link</button>
    </form>
    {% endif %}

    <p class="forgot-username-row"><a href="{{ url_for('login') }}">&larr; Back to Login</a></p>
  </div>
</div>
{% endblock %}
""",

    "forgot_username.html": """{% extends "base.html" %}
{% block title %}Forgot Username{% endblock %}
{% block content_noauth %}
<div class="login-wrap">
  <div class="login-card">
    <h1>Forgot Username</h1>
    <p class="sub">Apni registered email daalein, hum aapko username bhej dein ge</p>

    {% if sent %}
      <div class="flash flash-success">Agar ye email hamare system mein registered hai, to username us par bhej diya gaya hai.</div>
    {% endif %}
    {% if error %}
      <div class="flash flash-error">{{ error }}</div>
    {% endif %}

    {% if not sent %}
    <form method="POST">
      <div class="input-icon-wrap">
        <span class="input-icon">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><rect x="3" y="5" width="18" height="14" rx="2" stroke="#8b98a8" stroke-width="2"/><path d="M4 7l8 6 8-6" stroke="#8b98a8" stroke-width="2"/></svg>
        </span>
        <input type="email" name="email" placeholder="Your registered email" required autofocus>
      </div>
      <button class="btn login-btn" type="submit">Send Username</button>
    </form>
    {% endif %}

    <p class="forgot-username-row"><a href="{{ url_for('login') }}">&larr; Back to Login</a></p>
  </div>
</div>
{% endblock %}
""",

    "login.html": """{% extends "base.html" %}
{% block title %}Login - HR System{% endblock %}
{% block content_noauth %}
<div class="login-wrap">
  <div class="login-card">

    <div class="login-logo">
      <svg width="72" height="72" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
        <circle cx="50" cy="27" r="12" fill="#153a8b"/>
        <circle cx="24" cy="34" r="9" fill="#3a6fd8"/>
        <circle cx="76" cy="34" r="9" fill="#3a6fd8"/>
        <path d="M50 42c-13 0-22 9-22 20v6h44v-6c0-11-9-20-22-20z" fill="#153a8b"/>
        <path d="M24 46c-9 1-15 8-15 17v5h14v-8c0-6 2-11 6-15a17 17 0 0 0-5 1z" fill="#3a6fd8"/>
        <path d="M76 46c9 1 15 8 15 17v5H77v-8c0-6-2-11-6-15a17 17 0 0 1 5 1z" fill="#3a6fd8"/>
      </svg>
      <div class="login-hr-text">HR</div>
    </div>

    <h1>HR Management System</h1>
    <p class="sub">Smart HR &bull; Payroll &bull; Compliance</p>

    <form method="POST">
      <div class="input-icon-wrap">
        <span class="input-icon">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><circle cx="12" cy="8" r="4" stroke="#8b98a8" stroke-width="2"/><path d="M4 20c0-4.4 3.6-8 8-8s8 3.6 8 8" stroke="#8b98a8" stroke-width="2" stroke-linecap="round"/></svg>
        </span>
        <input type="text" name="username" placeholder="Username" required autofocus>
      </div>

      <div class="input-icon-wrap">
        <span class="input-icon">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><rect x="5" y="11" width="14" height="9" rx="2" stroke="#8b98a8" stroke-width="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3" stroke="#8b98a8" stroke-width="2"/></svg>
        </span>
        <input type="password" name="password" id="pwField" placeholder="Password" required>
        <span class="input-icon-right" onclick="togglePwd()">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7-10-7-10-7z" stroke="#8b98a8" stroke-width="2"/><circle cx="12" cy="12" r="3" stroke="#8b98a8" stroke-width="2"/></svg>
        </span>
      </div>

      <div class="login-row">
        <label class="checkbox-label"><input type="checkbox" checked disabled> Remember Me</label>
        <a href="{{ url_for('forgot_password') }}" class="forgot-link">Forgot Password?</a>
      </div>

      <button class="btn login-btn" type="submit">
        LOGIN <span class="arrow">&rarr;</span>
      </button>
    </form>

    <p class="forgot-username-row">Username bhool gaye? <a href="{{ url_for('forgot_username') }}">Username recover karein</a></p>

    <div class="login-features">
      <div><span class="feat-icon">🛡️</span><b>Secure</b><small>Your data is safe with us</small></div>
      <div><span class="feat-icon">⏱️</span><b>Reliable</b><small>Accurate &amp; timely processes</small></div>
      <div><span class="feat-icon">📊</span><b>Smart</b><small>AI powered HR insights</small></div>
    </div>
  </div>
  <div class="login-version">Version 1.0.0</div>
</div>

<script>
function togglePwd() {
  const f = document.getElementById('pwField');
  f.type = f.type === 'password' ? 'text' : 'password';
}
</script>
{% endblock %}
""",

    "payroll.html": """{% extends "base.html" %}
{% block title %}Payroll{% endblock %}
{% block content %}
<div class="page-header"><h1>Payroll</h1></div>

<div class="panel">
  <h2>Generate Payroll (auto-calculated from Attendance)</h2>
  <p style="font-size:13px;color:#6b7c93;">Rule: Per-day rate = Basic Salary ÷ {{ working_days_basis }}. Overtime paid at DOUBLE the per-hour rate.</p>
  <form method="POST">
    <div class="form-grid">
      <div><label>Employee</label>
        <select name="employee_id" required>
          <option value="">-- Select Employee --</option>
          {% for e in employees %}<option value="{{ e['id'] }}">{{ e['name'] }}</option>{% endfor %}
        </select>
      </div>
      <div><label>Month</label><input type="month" name="month" value="{{ month_default }}" required></div>
      <div><label>Deductions</label><input type="number" step="0.01" name="deductions" value="0"></div>
    </div>
    <button type="submit" class="btn">Calculate &amp; Generate Payroll</button>
  </form>
</div>

<div class="panel">
  <div class="page-header" style="margin-bottom:14px;">
    <h2 style="margin:0;">Payroll History</h2>
    <a href="{{ url_for('export_payroll_excel') }}" class="btn btn-secondary btn-sm">Export to Excel</a>
  </div>
  <div class="table-wrap">
  <table>
    <tr><th>Employee</th><th>Month</th><th>Present</th><th>Absent</th><th>OT hrs</th><th>Gross</th><th>Deductions</th><th>Net Salary</th><th>Generated By</th><th></th></tr>
    {% for r in rows %}
    <tr>
      <td>{{ r['emp_name'] }}</td><td>{{ r['month'] }}</td><td>{{ r['present_days'] }}</td><td>{{ r['absent_days'] }}</td>
      <td>{{ r['overtime_hours'] }}</td><td>{{ '{:,.2f}'.format(r['gross_salary']) }}</td>
      <td>{{ '{:,.2f}'.format(r['deductions']) }}</td><td>{{ '{:,.2f}'.format(r['net_salary']) }}</td>
      <td>{{ r['generated_by'] or '-' }}</td>
      <td class="btn-row">
        <a href="{{ url_for('pdf_payslip', payroll_id=r['id']) }}" target="_blank" class="btn btn-sm btn-secondary">PDF</a>
        <a href="{{ url_for('word_payslip', payroll_id=r['id']) }}" class="btn btn-sm btn-secondary">Word</a>
      </td>
    </tr>
    {% else %}
    <tr><td colspan="10">Koi payroll record nahi.</td></tr>
    {% endfor %}
  </table>
  </div>
</div>
{% endblock %}
""",

    "recruitment.html": """{% extends "base.html" %}
{% block title %}Recruitment{% endblock %}
{% block content %}
<div class="page-header"><h1>Recruitment</h1></div>

<div class="panel">
  <h2>Add Candidate</h2>
  <form method="POST">
    <div class="form-grid">
      <div><label>Name *</label><input type="text" name="name" required></div>
      <div><label>Contact</label><input type="text" name="contact"></div>
      <div><label>Position</label><input type="text" name="position"></div>
      <div><label>Stage</label>
        <select name="stage">
          {% for s in stages %}<option value="{{ s }}">{{ s }}</option>{% endfor %}
        </select>
      </div>
    </div>
    <label>Notes</label><textarea name="notes" rows="2"></textarea>
    <button type="submit" class="btn">Add Candidate</button>
  </form>
</div>

<div class="panel">
  <h2>Candidates</h2>
  <div class="table-wrap">
  <table>
    <tr><th>Name</th><th>Contact</th><th>Position</th><th>Stage</th><th>Applied On</th><th>Notes</th><th></th></tr>
    {% for c in candidates %}
    <tr>
      <td>{{ c['name'] }}</td><td>{{ c['contact'] or '-' }}</td><td>{{ c['position'] or '-' }}</td>
      <td>
        <form method="POST" action="{{ url_for('recruitment_update_stage', cid=c['id']) }}" style="display:inline;">
          <select name="stage" onchange="this.form.submit()">
            {% for s in stages %}<option value="{{ s }}" {{ 'selected' if c['stage']==s }}>{{ s }}</option>{% endfor %}
          </select>
        </form>
      </td>
      <td>{{ c['applied_on'] }}</td>
      <td>{{ c['notes'] or '-' }}</td>
      <td>
        <form method="POST" action="{{ url_for('recruitment_delete', cid=c['id']) }}" onsubmit="return confirm('Delete this candidate?');" style="display:inline;">
          <button type="submit" class="btn btn-sm btn-danger">Delete</button>
        </form>
      </td>
    </tr>
    {% else %}
    <tr><td colspan="7">Koi candidate nahi mila.</td></tr>
    {% endfor %}
  </table>
  </div>
</div>
{% endblock %}
""",

    "reset_password.html": """{% extends "base.html" %}
{% block title %}Reset Password{% endblock %}
{% block content_noauth %}
<div class="login-wrap">
  <div class="login-card">
    {% if invalid %}
      <h1>Link Invalid</h1>
      <p class="sub">Ye reset link expire ho chuka hai ya pehle use ho chuka hai.</p>
      <div class="flash flash-error">Dobara koshish karein.</div>
      <p class="forgot-username-row"><a href="{{ url_for('forgot_password') }}">Naya reset link mangwayein</a></p>
    {% else %}
      <h1>Reset Password</h1>
      <p class="sub">Apna naya password set karein</p>
      <form method="POST">
        <div class="input-icon-wrap">
          <span class="input-icon">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><rect x="5" y="11" width="14" height="9" rx="2" stroke="#8b98a8" stroke-width="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3" stroke="#8b98a8" stroke-width="2"/></svg>
          </span>
          <input type="password" name="new_password" placeholder="New Password" required autofocus>
        </div>
        <div class="input-icon-wrap">
          <span class="input-icon">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none"><rect x="5" y="11" width="14" height="9" rx="2" stroke="#8b98a8" stroke-width="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3" stroke="#8b98a8" stroke-width="2"/></svg>
          </span>
          <input type="password" name="confirm_password" placeholder="Confirm New Password" required>
        </div>
        <button class="btn login-btn" type="submit">Update Password</button>
      </form>
    {% endif %}
  </div>
</div>
{% endblock %}
""",

    "roster.html": """{% extends "base.html" %}
{% block title %}Roster{% endblock %}
{% block content %}
<div class="page-header"><h1>Shift Roster</h1></div>

<div class="panel">
  <h2>Quick Assign Shift</h2>
  <form method="POST">
    <input type="hidden" name="week_start" value="{{ week_start }}">
    <div class="form-grid">
      <div><label>Employee</label>
        <select name="employee_id" required>
          <option value="">-- Select Employee --</option>
          {% for e in employees %}<option value="{{ e['id'] }}">{{ e['name'] }} {% if e['department'] %}({{ e['department'] }}){% endif %}</option>{% endfor %}
        </select>
      </div>
      <div><label>Date</label><input type="date" name="date" value="{{ today }}" required></div>
      <div><label>Shift</label>
        <select name="shift">
          {% for s in shifts %}<option value="{{ s }}">{{ s }}</option>{% endfor %}
        </select>
      </div>
    </div>
    <button type="submit" class="btn">Assign Shift</button>
  </form>
</div>

<div class="panel">
  <div class="page-header" style="margin-bottom:14px;">
    <h2 style="margin:0;">Week: {{ week_dates[0] }} to {{ week_dates[-1] }}</h2>
    <div class="btn-row">
      <a href="{{ url_for('roster_page', week_start=prev_week) }}" class="btn btn-sm btn-secondary">&laquo; Previous Week</a>
      <a href="{{ url_for('roster_page', week_start=next_week) }}" class="btn btn-sm btn-secondary">Next Week &raquo;</a>
    </div>
  </div>

  <div class="table-wrap">
  <table>
    <tr>
      <th>Employee</th>
      {% for d in week_dates %}<th>{{ d.strftime('%a') }}<br><span style="font-weight:400;">{{ d }}</span></th>{% endfor %}
    </tr>
    {% for e in employees %}
    <tr>
      <td>{{ e['name'] }}{% if e['department'] %}<br><span style="color:#8b98a8;font-size:11px;">{{ e['department'] }}</span>{% endif %}</td>
      {% for d in week_dates %}
      {% set current_shift = roster_map.get((e['id'], d|string), '') %}
      <td>
        <form method="POST" action="{{ url_for('roster_page') }}">
          <input type="hidden" name="employee_id" value="{{ e['id'] }}">
          <input type="hidden" name="date" value="{{ d }}">
          <input type="hidden" name="week_start" value="{{ week_start }}">
          <select name="shift" onchange="this.form.submit()" style="margin-bottom:0; padding:5px; font-size:12px;">
            <option value="">-</option>
            {% for s in shifts %}<option value="{{ s }}" {{ 'selected' if current_shift==s }}>{{ s }}</option>{% endfor %}
          </select>
        </form>
      </td>
      {% endfor %}
    </tr>
    {% else %}
    <tr><td colspan="8">Koi active employee nahi mila.</td></tr>
    {% endfor %}
  </table>
  </div>
</div>
{% endblock %}
""",

    "salary_increment.html": """{% extends "base.html" %}
{% block title %}Salary Increment - {{ emp['name'] }}{% endblock %}
{% block content %}
<div class="page-header">
  <h1>Salary Increment — {{ emp['name'] }}</h1>
  <a href="{{ url_for('employee_view', emp_id=emp['id']) }}" class="btn btn-secondary">Back to Profile</a>
</div>

<div class="panel">
  <h2>Current Salary: {{ '{:,.2f}'.format(emp['basic_salary']) if emp['basic_salary'] else '0.00' }}</h2>
  <form method="POST">
    <div class="form-grid">
      <div><label>New Salary *</label><input type="number" step="0.01" name="new_salary" required></div>
      <div><label>Effective Date</label><input type="date" name="effective_date" value="{{ today }}"></div>
      <div><label>Reason</label><input type="text" name="reason" placeholder="e.g. Annual Increment, Promotion"></div>
    </div>
    <button type="submit" class="btn">Update Salary</button>
  </form>
</div>

<div class="panel">
  <h2>Increment History</h2>
  <div class="table-wrap">
  <table>
    <tr><th>Effective Date</th><th>Old Salary</th><th>New Salary</th><th>Change</th><th>Reason</th><th>Updated By</th></tr>
    {% for h in history %}
    <tr>
      <td>{{ h['effective_date'] }}</td>
      <td>{{ '{:,.2f}'.format(h['old_salary']) }}</td>
      <td>{{ '{:,.2f}'.format(h['new_salary']) }}</td>
      <td>{{ '{:+,.2f}'.format(h['new_salary'] - h['old_salary']) }}</td>
      <td>{{ h['reason'] or '-' }}</td>
      <td>{{ h['updated_by'] or '-' }}</td>
    </tr>
    {% else %}
    <tr><td colspan="6">Abhi tak koi increment record nahi.</td></tr>
    {% endfor %}
  </table>
  </div>
</div>
{% endblock %}
""",

    "users.html": """{% extends "base.html" %}
{% block title %}Manage Users{% endblock %}
{% block content %}
<div class="page-header"><h1>Manage Users</h1></div>

{% if not smtp_configured %}
<div class="panel">
  <div class="flash flash-error" style="margin:0;">
    Email service (SMTP) abhi set nahi hai — isliye "Forgot Username/Password" self-service kaam nahi karega.
    DEPLOY.txt mein SMTP setup instructions dekhein. Tab tak, users ka password neeche se manually reset kar sakte hain.
  </div>
</div>
{% endif %}

<div class="panel">
  <h2>Add New User</h2>
  <form method="POST">
    <div class="form-grid">
      <div><label>Username *</label><input type="text" name="username" required></div>
      <div><label>Password *</label><input type="password" name="password" required></div>
      <div><label>Full Name</label><input type="text" name="full_name"></div>
      <div><label>Email</label><input type="email" name="email" placeholder="for password/username recovery"></div>
      <div><label>Role</label>
        <select name="role">
          <option value="HR Staff">HR Staff</option>
          <option value="Admin">Admin</option>
        </select>
      </div>
    </div>
    <button type="submit" class="btn">Add User</button>
  </form>
</div>

<div class="panel">
  <h2>Existing Users</h2>
  <div class="table-wrap">
  <table>
    <tr><th>Username</th><th>Full Name</th><th>Email</th><th>Role</th><th>Created</th><th></th></tr>
    {% for u in users %}
    <tr>
      <td>{{ u['username'] }}</td><td>{{ u['full_name'] or '-' }}</td><td>{{ u['email'] or '-' }}</td><td>{{ u['role'] }}</td><td>{{ u['created_at'][:16] }}</td>
      <td class="btn-row">
        <form method="POST" action="{{ url_for('user_reset_password', uid=u['id']) }}" onsubmit="return confirm('Reset password for {{ u['username'] }}? A temporary password will be shown.');" style="display:inline;">
          <button type="submit" class="btn btn-sm btn-secondary">Reset Password</button>
        </form>
        <form method="POST" action="{{ url_for('user_delete', uid=u['id']) }}" onsubmit="return confirm('Delete this user?');" style="display:inline;">
          <button type="submit" class="btn btn-sm btn-danger">Delete</button>
        </form>
      </td>
    </tr>
    {% endfor %}
  </table>
  </div>
</div>
{% endblock %}
""",

}
