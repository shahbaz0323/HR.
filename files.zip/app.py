"""
HR Management & Audit System - WEB APPLICATION (Flask)
=========================================================
Multi-user, login-protected, online-hostable HR system.

MODULES: Employees/Personal File, Attendance, Payroll, Recruitment, User Management
Login: session-based (no extra auth library needed)
Database: SQLite (hr_web.db) - for real online multi-user use with more traffic,
          this can later be swapped to PostgreSQL/MySQL with minimal changes.

RUN LOCALLY:
    pip install -r requirements.txt
    python3 app.py
    Open: http://127.0.0.1:5000

DEFAULT LOGIN (created automatically on first run):
    username: admin
    password: admin123
    >>> Please change this password immediately after first login. <<<

See DEPLOY.txt for instructions on putting this online.
"""

import os
import json
import sqlite3
import secrets
import smtplib
from email.mime.text import MIMEText
from datetime import date, datetime, timedelta
from functools import wraps

from flask import (
    Flask, render_template, request, redirect, url_for, session, flash,
    send_file, send_from_directory, abort
)
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from jinja2 import DictLoader

from templates_data import TEMPLATES
from assets_data import ICON_192_B64, ICON_512_B64

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image as RLImage, PageBreak
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY

import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
from io import BytesIO

from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH

try:
    import anthropic
    ANTHROPIC_OK = True
except ImportError:
    ANTHROPIC_OK = False

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_FILE = os.path.join(BASE_DIR, "hr_web.db")
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")
PDF_DIR = os.path.join(BASE_DIR, "generated_pdfs")
ALLOWED_IMG_EXT = {"png", "jpg", "jpeg"}

os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(PDF_DIR, exist_ok=True)

app = Flask(__name__)
app.secret_key = os.environ.get("HR_SECRET_KEY", "change-this-secret-key-before-deploying")
app.jinja_env.loader = DictLoader(TEMPLATES)  # templates embedded in templates_data.py - no templates/ folder needed

WORKING_DAYS_BASIS = 26  # salary calculated on 26-day basis, overtime at double rate


# ============================================================
#  DATABASE
# ============================================================
def get_conn():
    conn = sqlite3.connect(DB_FILE)
    conn.execute("PRAGMA foreign_keys = ON")
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_conn()
    c = conn.cursor()

    c.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            full_name TEXT,
            email TEXT,
            role TEXT DEFAULT 'HR Staff',   -- Admin / HR Staff
            created_at TEXT
        )
    """)

    # Migration: add email column if this DB was created before this field existed
    existing_cols = [row["name"] for row in conn.execute("PRAGMA table_info(users)").fetchall()]
    if "email" not in existing_cols:
        conn.execute("ALTER TABLE users ADD COLUMN email TEXT")

    c.execute("""
        CREATE TABLE IF NOT EXISTS password_reset_tokens (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            token TEXT UNIQUE NOT NULL,
            created_at TEXT,
            expires_at TEXT,
            used INTEGER DEFAULT 0,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS employees (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            emp_code TEXT,
            name TEXT NOT NULL,
            father_name TEXT,
            dob TEXT,
            marital_status TEXT,
            nic_number TEXT,
            contact TEXT,
            address TEXT,
            photo_path TEXT,
            nic_front_path TEXT,
            nic_back_path TEXT,
            company TEXT,
            department TEXT,
            designation TEXT,
            section TEXT,
            appointment_date TEXT,
            leave_date TEXT,
            status TEXT DEFAULT 'Active',
            basic_salary REAL DEFAULT 0,
            bank_name TEXT,
            bank_account_title TEXT,
            bank_account_number TEXT,
            bank_iban TEXT,
            created_by TEXT,
            updated_by TEXT,
            updated_at TEXT
        )
    """)

    # Migration: add bank columns if this DB was created before these fields existed
    existing_emp_cols = [row["name"] for row in conn.execute("PRAGMA table_info(employees)").fetchall()]
    for col in ["bank_name", "bank_account_title", "bank_account_number", "bank_iban"]:
        if col not in existing_emp_cols:
            conn.execute(f"ALTER TABLE employees ADD COLUMN {col} TEXT")

    c.execute("""
        CREATE TABLE IF NOT EXISTS attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_id INTEGER NOT NULL,
            date TEXT NOT NULL,
            status TEXT NOT NULL,
            overtime_hours REAL DEFAULT 0,
            marked_by TEXT,
            FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS payroll (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_id INTEGER NOT NULL,
            month TEXT NOT NULL,
            present_days INTEGER,
            absent_days INTEGER,
            leave_days INTEGER,
            overtime_hours REAL,
            basic_salary REAL,
            per_day_rate REAL,
            overtime_hourly_rate REAL,
            overtime_amount REAL,
            gross_salary REAL,
            deductions REAL DEFAULT 0,
            net_salary REAL,
            generated_on TEXT,
            generated_by TEXT,
            FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS candidates (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            contact TEXT,
            position TEXT,
            stage TEXT DEFAULT 'Applied',
            applied_on TEXT,
            notes TEXT,
            created_by TEXT
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS departments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS roster (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_id INTEGER NOT NULL,
            date TEXT NOT NULL,
            shift TEXT NOT NULL,          -- Morning / Evening / Night / Off
            assigned_by TEXT,
            FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE,
            UNIQUE(employee_id, date)
        )
    """)

    c.execute("""
        CREATE TABLE IF NOT EXISTS salary_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            employee_id INTEGER NOT NULL,
            old_salary REAL,
            new_salary REAL,
            effective_date TEXT,
            reason TEXT,
            updated_by TEXT,
            updated_at TEXT,
            FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
        )
    """)

    conn.commit()

    # Seed default admin user if no users exist yet
    existing = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
    if existing == 0:
        conn.execute(
            "INSERT INTO users (username, password_hash, full_name, email, role, created_at) VALUES (?,?,?,?,?,?)",
            ("admin", generate_password_hash("admin123"), "Administrator",
             "shahbaz0323324916@gmail.com", "Admin", str(datetime.now())),
        )
        conn.commit()

    conn.close()


def calc_age(dob_str):
    try:
        y, m, d = map(int, dob_str.split("-"))
        born = date(y, m, d)
        today = date.today()
        return today.year - born.year - ((today.month, today.day) < (born.month, born.day))
    except Exception:
        return "N/A"


def allowed_image(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_IMG_EXT


def smtp_configured():
    return all(os.environ.get(k) for k in ["SMTP_HOST", "SMTP_USER", "SMTP_PASSWORD"])


def send_email(to_email, subject, body):
    """Sends a plain-text email via SMTP using environment variables.
    Returns True on success, False if not configured or on failure."""
    if not smtp_configured():
        return False
    host = os.environ.get("SMTP_HOST")
    port = int(os.environ.get("SMTP_PORT", "587"))
    user = os.environ.get("SMTP_USER")
    password = os.environ.get("SMTP_PASSWORD")
    from_addr = os.environ.get("SMTP_FROM", user)

    msg = MIMEText(body)
    msg["Subject"] = subject
    msg["From"] = from_addr
    msg["To"] = to_email

    try:
        with smtplib.SMTP(host, port, timeout=15) as server:
            server.starttls()
            server.login(user, password)
            server.sendmail(from_addr, [to_email], msg.as_string())
        return True
    except Exception:
        return False


# ============================================================
#  AUTH HELPERS
# ============================================================
def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login", next=request.path))
        return f(*args, **kwargs)
    return wrapper


def admin_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))
        if session.get("role") != "Admin":
            flash("Sirf Admin ye page access kar sakta hai.", "error")
            return redirect(url_for("dashboard"))
        return f(*args, **kwargs)
    return wrapper


@app.context_processor
def inject_user():
    return {
        "current_username": session.get("username"),
        "current_role": session.get("role"),
        "today": str(date.today()),
    }


# ============================================================
#  AUTH ROUTES
# ============================================================
# ============================================================
#  PWA SUPPORT (Install as an App on Mobile - manifest, service worker, icons)
# ============================================================
import base64
from flask import Response

@app.route("/manifest.json")
def pwa_manifest():
    manifest = {
        "name": "HR Management System",
        "short_name": "HR System",
        "description": "Smart HR, Payroll & Compliance system",
        "start_url": "/",
        "display": "standalone",
        "background_color": "#eef3fb",
        "theme_color": "#10265c",
        "orientation": "portrait",
        "icons": [
            {"src": "/icon-192.png", "sizes": "192x192", "type": "image/png", "purpose": "any maskable"},
            {"src": "/icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any maskable"},
        ],
    }
    return Response(json.dumps(manifest), mimetype="application/manifest+json")


@app.route("/icon-192.png")
def pwa_icon_192():
    return Response(base64.b64decode(ICON_192_B64), mimetype="image/png")


@app.route("/icon-512.png")
def pwa_icon_512():
    return Response(base64.b64decode(ICON_512_B64), mimetype="image/png")


@app.route("/sw.js")
def pwa_service_worker():
    sw_code = """
const CACHE_NAME = 'hr-system-v1';
self.addEventListener('install', (event) => {
  self.skipWaiting();
});
self.addEventListener('activate', (event) => {
  self.clients.claim();
});
self.addEventListener('fetch', (event) => {
  // Network-first: always try live data first (HR data must stay fresh),
  // fall back to cache only if offline.
  event.respondWith(
    fetch(event.request).catch(() => caches.match(event.request))
  );
});
"""
    return Response(sw_code, mimetype="application/javascript")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        conn = get_conn()
        user = conn.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
        conn.close()
        if user and check_password_hash(user["password_hash"], password):
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            session["role"] = user["role"]
            session["full_name"] = user["full_name"]
            flash(f"Welcome, {user['full_name'] or user['username']}!", "success")
            return redirect(request.args.get("next") or url_for("dashboard"))
        flash("Username ya password ghalat hai.", "error")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/emergency-admin-reset")
def emergency_admin_reset():
    """Recovery route: resets the 'admin' account's password back to admin123.
    Protected by EMERGENCY_RESET_KEY environment variable - only works if that
    variable is set AND matches the ?key= provided in the URL. This exists so
    you're never permanently locked out even if the admin password is lost."""
    provided_key = request.args.get("key", "")
    expected_key = os.environ.get("EMERGENCY_RESET_KEY", "")
    if not expected_key or provided_key != expected_key:
        abort(404)

    conn = get_conn()
    admin_user = conn.execute("SELECT * FROM users WHERE username='admin'").fetchone()
    if admin_user:
        conn.execute("UPDATE users SET password_hash=? WHERE username='admin'",
                     (generate_password_hash("admin123"),))
        conn.commit()
        conn.close()
        return ("Admin password has been reset to: admin123<br>"
                "Please login now and change it immediately from 'Change Password'.")
    conn.close()
    return "No 'admin' user found.", 404


@app.route("/forgot-username", methods=["GET", "POST"])
def forgot_username():
    sent = False
    error = None
    if request.method == "POST":
        email = request.form.get("email", "").strip()
        conn = get_conn()
        user = conn.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
        conn.close()
        if not smtp_configured():
            error = ("Email service abhi set up nahi hai. Admin se rabta karein apna username jaan-ne ke liye. "
                      "(Admin ke liye: DEPLOY.txt mein SMTP setup instructions hain)")
        elif user:
            send_email(
                email, "Your HR System Username",
                f"Assalam-o-Alaikum {user['full_name'] or ''},\n\n"
                f"Aapka username hai: {user['username']}\n\n"
                f"Agar aap ne ye request nahi ki, is email ko ignore karein."
            )
            sent = True
        else:
            # Don't reveal whether the email exists - show generic success either way
            sent = True
    return render_template("forgot_username.html", sent=sent, error=error)


@app.route("/forgot-password", methods=["GET", "POST"])
def forgot_password():
    sent = False
    error = None
    if request.method == "POST":
        email = request.form.get("email", "").strip()
        conn = get_conn()
        user = conn.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()

        if not smtp_configured():
            error = ("Email service abhi set up nahi hai. Admin se rabta karein password reset ke liye. "
                      "(Admin ke liye: DEPLOY.txt mein SMTP setup instructions hain)")
        elif user:
            token = secrets.token_urlsafe(32)
            expires = str(datetime.now() + timedelta(hours=1))
            conn.execute(
                "INSERT INTO password_reset_tokens (user_id, token, created_at, expires_at, used) VALUES (?,?,?,?,0)",
                (user["id"], token, str(datetime.now()), expires),
            )
            conn.commit()
            reset_link = url_for("reset_password", token=token, _external=True)
            send_email(
                email, "Reset Your HR System Password",
                f"Assalam-o-Alaikum {user['full_name'] or ''},\n\n"
                f"Apna password reset karne ke liye ye link kholein (1 hour tak valid hai):\n{reset_link}\n\n"
                f"Agar aap ne ye request nahi ki, is email ko ignore karein."
            )
            sent = True
        else:
            sent = True  # generic response - don't reveal whether email exists
        conn.close()
    return render_template("forgot_password.html", sent=sent, error=error)


@app.route("/reset-password/<token>", methods=["GET", "POST"])
def reset_password(token):
    conn = get_conn()
    row = conn.execute("SELECT * FROM password_reset_tokens WHERE token=?", (token,)).fetchone()

    valid = False
    if row and not row["used"]:
        try:
            expires_at = datetime.fromisoformat(row["expires_at"])
            valid = datetime.now() < expires_at
        except Exception:
            valid = False

    if not valid:
        conn.close()
        return render_template("reset_password.html", invalid=True)

    if request.method == "POST":
        new_password = request.form.get("new_password", "")
        confirm_password = request.form.get("confirm_password", "")
        if not new_password or new_password != confirm_password:
            conn.close()
            flash("Password match nahi kar rahe ya khali hai.", "error")
            return render_template("reset_password.html", invalid=False, token=token)

        conn.execute("UPDATE users SET password_hash=? WHERE id=?",
                     (generate_password_hash(new_password), row["user_id"]))
        conn.execute("UPDATE password_reset_tokens SET used=1 WHERE id=?", (row["id"],))
        conn.commit()
        conn.close()
        flash("Password successfully reset ho gaya. Ab login karein.", "success")
        return redirect(url_for("login"))

    conn.close()
    return render_template("reset_password.html", invalid=False, token=token)


# ============================================================
#  DASHBOARD
# ============================================================
@app.route("/")
@login_required
def dashboard():
    conn = get_conn()
    total_employees = conn.execute("SELECT COUNT(*) FROM employees WHERE status='Active'").fetchone()[0]
    total_left = conn.execute("SELECT COUNT(*) FROM employees WHERE status='Left'").fetchone()[0]
    today_present = conn.execute(
        "SELECT COUNT(*) FROM attendance WHERE date=? AND status='Present'", (str(date.today()),)
    ).fetchone()[0]
    pending_candidates = conn.execute(
        "SELECT COUNT(*) FROM candidates WHERE stage NOT IN ('Hired','Rejected')"
    ).fetchone()[0]
    recent_employees = conn.execute(
        "SELECT * FROM employees ORDER BY id DESC LIMIT 5"
    ).fetchall()
    conn.close()
    return render_template(
        "dashboard.html",
        total_employees=total_employees,
        total_left=total_left,
        today_present=today_present,
        pending_candidates=pending_candidates,
        recent_employees=recent_employees,
    )


# ============================================================
#  EMPLOYEES
# ============================================================
def _style_excel_header(ws, row_num, num_cols):
    header_fill = PatternFill(start_color="163A8E", end_color="163A8E", fill_type="solid")
    header_font = Font(color="FFFFFF", bold=True)
    for col in range(1, num_cols + 1):
        cell = ws.cell(row=row_num, column=col)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center")


def _autofit_columns(ws):
    for col in ws.columns:
        max_len = max((len(str(c.value)) for c in col if c.value is not None), default=8)
        ws.column_dimensions[col[0].column_letter].width = min(max_len + 3, 40)


@app.route("/employees/export/excel")
@login_required
def export_employees_excel():
    conn = get_conn()
    rows = conn.execute("SELECT * FROM employees ORDER BY id").fetchall()
    conn.close()

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Employees"
    headers = ["ID", "Code", "Name", "Father Name", "DOB", "Marital Status", "NIC Number", "Contact",
               "Address", "Company", "Department", "Designation", "Section", "Appointment Date",
               "Leave Date", "Status", "Basic Salary", "Bank Name", "Account Title", "Account Number", "IBAN"]
    ws.append(headers)
    _style_excel_header(ws, 1, len(headers))

    for e in rows:
        ws.append([e["id"], e["emp_code"], e["name"], e["father_name"], e["dob"], e["marital_status"],
                   e["nic_number"], e["contact"], e["address"], e["company"], e["department"],
                   e["designation"], e["section"], e["appointment_date"], e["leave_date"], e["status"],
                   e["basic_salary"], e["bank_name"], e["bank_account_title"], e["bank_account_number"],
                   e["bank_iban"]])
    _autofit_columns(ws)

    buf = BytesIO()
    wb.save(buf)
    buf.seek(0)
    return send_file(buf, as_attachment=True, download_name="employees.xlsx",
                      mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


@app.route("/attendance/export/excel")
@login_required
def export_attendance_excel():
    emp_id = request.args.get("employee_id", "")
    month = request.args.get("month", "")
    conn = get_conn()
    query = """SELECT attendance.date, employees.name, attendance.status, attendance.overtime_hours,
                      attendance.marked_by
               FROM attendance JOIN employees ON attendance.employee_id = employees.id WHERE 1=1"""
    params = []
    if emp_id:
        query += " AND employees.id=?"
        params.append(emp_id)
    if month:
        query += " AND attendance.date LIKE ?"
        params.append(f"{month}%")
    query += " ORDER BY attendance.date"
    rows = conn.execute(query, params).fetchall()
    conn.close()

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Attendance"
    headers = ["Date", "Employee", "Status", "Overtime (hrs)", "Marked By"]
    ws.append(headers)
    _style_excel_header(ws, 1, len(headers))
    for r in rows:
        ws.append([r["date"], r["name"], r["status"], r["overtime_hours"], r["marked_by"]])
    _autofit_columns(ws)

    buf = BytesIO()
    wb.save(buf)
    buf.seek(0)
    return send_file(buf, as_attachment=True, download_name="attendance.xlsx",
                      mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


@app.route("/payroll/export/excel")
@login_required
def export_payroll_excel():
    conn = get_conn()
    rows = conn.execute("""
        SELECT payroll.*, employees.name as emp_name FROM payroll
        JOIN employees ON payroll.employee_id = employees.id ORDER BY payroll.id DESC
    """).fetchall()
    conn.close()

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Payroll"
    headers = ["Employee", "Month", "Present", "Absent", "Leave", "Overtime (hrs)", "Basic Salary",
               "Per Day Rate", "Overtime Rate", "Overtime Amount", "Gross Salary", "Deductions",
               "Net Salary", "Generated On", "Generated By"]
    ws.append(headers)
    _style_excel_header(ws, 1, len(headers))
    for r in rows:
        ws.append([r["emp_name"], r["month"], r["present_days"], r["absent_days"], r["leave_days"],
                   r["overtime_hours"], r["basic_salary"], r["per_day_rate"], r["overtime_hourly_rate"],
                   r["overtime_amount"], r["gross_salary"], r["deductions"], r["net_salary"],
                   r["generated_on"], r["generated_by"]])
    _autofit_columns(ws)

    buf = BytesIO()
    wb.save(buf)
    buf.seek(0)
    return send_file(buf, as_attachment=True, download_name="payroll.xlsx",
                      mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


@app.route("/employees/export/excel-template")
@login_required
def export_employee_import_template():
    """Downloadable blank Excel template with the correct column headers for bulk import."""
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Employees"
    headers = ["Employee Code", "Name", "Father Name", "DOB (YYYY-MM-DD)", "Marital Status",
               "NIC Number", "Contact", "Address", "Company", "Department", "Designation",
               "Section", "Appointment Date (YYYY-MM-DD)", "Basic Salary", "Bank Name",
               "Account Title", "Account Number", "IBAN"]
    ws.append(headers)
    _style_excel_header(ws, 1, len(headers))
    ws.append(["EMP-001", "Ali Raza", "Muhammad Raza", "1995-05-10", "Single", "12345-1234567-1",
               "0300-1234567", "Karachi", "Test Textiles Ltd", "Production", "Machine Operator",
               "Production", "2024-01-01", 26000, "HBL", "Ali Raza", "01234567890123", "PK00HABB0000000000000000"])
    _autofit_columns(ws)

    buf = BytesIO()
    wb.save(buf)
    buf.seek(0)
    return send_file(buf, as_attachment=True, download_name="employee_import_template.xlsx",
                      mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


@app.route("/employees/import", methods=["GET", "POST"])
@login_required
def employees_import():
    result = None
    if request.method == "POST":
        file = request.files.get("excel_file")
        if not file or not file.filename:
            flash("Pehle Excel file select karein.", "error")
            return redirect(url_for("employees_import"))
        try:
            wb = openpyxl.load_workbook(file, data_only=True)
            ws = wb.active
            rows = list(ws.iter_rows(min_row=2, values_only=True))  # skip header row
        except Exception as e:
            flash(f"Excel file parh nahi saki: {e}", "error")
            return redirect(url_for("employees_import"))

        conn = get_conn()
        added, skipped = 0, 0
        for row in rows:
            if not row or not row[0] and not (len(row) > 1 and row[1]):
                continue
            # Columns: Code, Name, Father, DOB, Marital, NIC, Contact, Address, Company, Dept,
            #          Designation, Section, AppointmentDate, Salary, Bank, AcctTitle, AcctNum, IBAN
            name = row[1] if len(row) > 1 else None
            if not name or not str(name).strip():
                skipped += 1
                continue
            try:
                salary = float(row[13]) if len(row) > 13 and row[13] not in (None, "") else 0
            except (ValueError, TypeError):
                salary = 0

            def s(idx):
                return str(row[idx]).strip() if len(row) > idx and row[idx] is not None else ""

            def d(idx):
                """Format date-like cell values as YYYY-MM-DD strings."""
                if len(row) <= idx or row[idx] is None:
                    return ""
                val = row[idx]
                if isinstance(val, (datetime, date)):
                    return val.strftime("%Y-%m-%d")
                return str(val).strip()

            conn.execute("""
                INSERT INTO employees (emp_code, name, father_name, dob, marital_status, nic_number,
                    contact, address, company, department, designation, section, appointment_date,
                    status, basic_salary, bank_name, bank_account_title, bank_account_number, bank_iban,
                    created_by, updated_by, updated_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """, (s(0), str(name).strip(), s(2), d(3), s(4), s(5), s(6), s(7), s(8), s(9), s(10), s(11),
                  d(12), "Active", salary, s(14), s(15), s(16), s(17),
                  session["username"], session["username"], str(datetime.now())))
            added += 1
        conn.commit()
        conn.close()
        result = {"added": added, "skipped": skipped}
        flash(f"{added} employees import ho gaye. ({skipped} khali/ghalat rows skip hui)", "success")

    return render_template("employees_import.html", result=result)


def _docx_employee_info(doc, emp):
    table = doc.add_table(rows=0, cols=2)
    table.style = "Light Grid Accent 1"
    age = calc_age(emp["dob"]) if emp["dob"] else "N/A"
    rows_data = [
        ("Employee Code", emp["emp_code"] or "-"), ("Status", emp["status"]),
        ("Name", emp["name"]), ("Father Name", emp["father_name"] or "-"),
        ("Date of Birth", f"{emp['dob'] or '-'} ({age} yrs)"), ("Marital Status", emp["marital_status"] or "-"),
        ("NIC Number", emp["nic_number"] or "-"), ("Contact", emp["contact"] or "-"),
        ("Address", emp["address"] or "-"), ("Company", emp["company"] or "-"),
        ("Department", emp["department"] or "-"), ("Designation", emp["designation"] or "-"),
        ("Section", emp["section"] or "-"), ("Appointment Date", emp["appointment_date"] or "-"),
        ("Leave Date", emp["leave_date"] or "-"),
        ("Basic Salary", f"{emp['basic_salary']:,.2f}" if emp["basic_salary"] else "-"),
        ("Bank Name", emp["bank_name"] or "-"), ("Account Title", emp["bank_account_title"] or "-"),
        ("Account Number", emp["bank_account_number"] or "-"), ("IBAN", emp["bank_iban"] or "-"),
    ]
    for label, value in rows_data:
        row = table.add_row()
        row.cells[0].text = label
        row.cells[0].paragraphs[0].runs[0].bold = True
        row.cells[1].text = str(value)
    return table


@app.route("/employees/<int:emp_id>/word/appointment_letter")
@login_required
def word_appointment_letter(emp_id):
    conn = get_conn()
    emp = conn.execute("SELECT * FROM employees WHERE id=?", (emp_id,)).fetchone()
    conn.close()
    if not emp:
        abort(404)

    doc = Document()
    title = doc.add_heading(emp["company"] or "COMPANY NAME", level=1)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    sub = doc.add_paragraph("Appointment Letter")
    sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    doc.add_paragraph(f"Date: {emp['appointment_date'] or str(date.today())}")

    body = doc.add_paragraph()
    body.add_run(f"Dear {emp['name']} S/D/O {emp['father_name'] or '-'},\n\n").bold = False
    body.add_run(
        f"We are pleased to confirm your appointment with {emp['company'] or 'the company'} as "
        f"{emp['designation'] or '-'} in the {emp['department'] or '-'} department "
        f"({emp['section'] or '-'} section), with effect from {emp['appointment_date'] or '-'}.\n\n"
        f"Your NIC number on record is {emp['nic_number'] or '-'}. Your monthly basic salary has been "
        f"fixed at {emp['basic_salary']:,.2f}, subject to the company's attendance and leave policy. "
        f"Salary is calculated on a 26-day basis, and any overtime worked will be compensated at double "
        f"the standard hourly rate.\n\n"
        f"You are required to abide by all company rules, regulations, and codes of conduct during your "
        f"employment.\n\nWe welcome you to the team and wish you a successful career with us."
    )
    doc.add_paragraph("\n\n_____________________________")
    doc.add_paragraph("Authorized Signature (HR Department)")

    buf = BytesIO()
    doc.save(buf)
    buf.seek(0)
    return send_file(buf, as_attachment=True, download_name=f"appointment_letter_{emp['name']}.docx",
                      mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document")


@app.route("/employees/<int:emp_id>/word/personal_file")
@login_required
def word_personal_file(emp_id):
    conn = get_conn()
    emp = conn.execute("SELECT * FROM employees WHERE id=?", (emp_id,)).fetchone()
    attendance_rows = conn.execute(
        "SELECT date, status, overtime_hours FROM attendance WHERE employee_id=? ORDER BY date", (emp_id,)
    ).fetchall()
    payroll_rows = conn.execute(
        "SELECT month, present_days, absent_days, overtime_hours, gross_salary, deductions, net_salary "
        "FROM payroll WHERE employee_id=? ORDER BY month", (emp_id,)
    ).fetchall()
    conn.close()
    if not emp:
        abort(404)

    doc = Document()
    title = doc.add_heading(emp["company"] or "COMPANY NAME", level=1)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    sub = doc.add_paragraph(f"Employee Personal File — {emp['name']}")
    sub.alignment = WD_ALIGN_PARAGRAPH.CENTER

    photo = _abs_path(emp["photo_path"])
    if photo:
        try:
            doc.add_picture(photo, width=Inches(1.2))
        except Exception:
            pass

    doc.add_heading("1. Personal & Employment Details", level=2)
    _docx_employee_info(doc, emp)

    doc.add_heading("2. National Identity Card (NIC)", level=2)
    nic_front = _abs_path(emp["nic_front_path"])
    nic_back = _abs_path(emp["nic_back_path"])
    if nic_front:
        try:
            doc.add_picture(nic_front, width=Inches(3))
        except Exception:
            pass
    if nic_back:
        try:
            doc.add_picture(nic_back, width=Inches(3))
        except Exception:
            pass
    if not nic_front and not nic_back:
        doc.add_paragraph("NIC images not uploaded.")

    doc.add_page_break()
    doc.add_heading("3. Attendance Record", level=2)
    if attendance_rows:
        t = doc.add_table(rows=1, cols=3)
        t.style = "Light Grid Accent 1"
        hdr = t.rows[0].cells
        hdr[0].text, hdr[1].text, hdr[2].text = "Date", "Status", "Overtime (hrs)"
        for a in attendance_rows:
            row = t.add_row().cells
            row[0].text, row[1].text, row[2].text = a["date"], a["status"], str(a["overtime_hours"])
    else:
        doc.add_paragraph("No attendance records found.")

    doc.add_heading("4. Payroll History", level=2)
    if payroll_rows:
        t = doc.add_table(rows=1, cols=6)
        t.style = "Light Grid Accent 1"
        hdr = t.rows[0].cells
        for i, h in enumerate(["Month", "Present", "Absent", "OT hrs", "Gross", "Net Salary"]):
            hdr[i].text = h
        for p in payroll_rows:
            row = t.add_row().cells
            row[0].text = p["month"]
            row[1].text = str(p["present_days"])
            row[2].text = str(p["absent_days"])
            row[3].text = str(p["overtime_hours"])
            row[4].text = f"{p['gross_salary']:,.2f}"
            row[5].text = f"{p['net_salary']:,.2f}"
    else:
        doc.add_paragraph("No payroll records found.")

    doc.add_paragraph(f"\nGenerated on: {datetime.now().strftime('%Y-%m-%d %H:%M')} — For Audit Purposes")

    buf = BytesIO()
    doc.save(buf)
    buf.seek(0)
    return send_file(buf, as_attachment=True, download_name=f"personal_file_{emp['name']}.docx",
                      mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document")


@app.route("/payroll/<int:payroll_id>/word")
@login_required
def word_payslip(payroll_id):
    conn = get_conn()
    row = conn.execute("""
        SELECT payroll.*, employees.name as emp_name, employees.bank_name, employees.bank_account_title,
               employees.bank_account_number, employees.bank_iban
        FROM payroll JOIN employees ON payroll.employee_id = employees.id WHERE payroll.id=?
    """, (payroll_id,)).fetchone()
    conn.close()
    if not row:
        abort(404)

    doc = Document()
    title = doc.add_heading("Salary Slip", level=1)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    sub = doc.add_paragraph(f"Employee: {row['emp_name']} | Month: {row['month']}")
    sub.alignment = WD_ALIGN_PARAGRAPH.CENTER

    t = doc.add_table(rows=0, cols=2)
    t.style = "Light Grid Accent 1"
    data_rows = [
        ("Basic Salary", f"{row['basic_salary']:,.2f}"),
        ("Per Day Rate (Salary/26)", f"{row['per_day_rate']:,.2f}"),
        ("Present Days", str(row["present_days"])),
        ("Absent Days", str(row["absent_days"])),
        ("Leave Days", str(row["leave_days"])),
        ("Overtime Hours", str(row["overtime_hours"])),
        ("Overtime Rate (double, per hour)", f"{row['overtime_hourly_rate']:,.2f}"),
        ("Overtime Amount", f"{row['overtime_amount']:,.2f}"),
        ("Gross Salary", f"{row['gross_salary']:,.2f}"),
        ("Deductions", f"{row['deductions']:,.2f}"),
        ("NET SALARY", f"{row['net_salary']:,.2f}"),
        ("Bank Name", row["bank_name"] or "-"),
        ("Account Title", row["bank_account_title"] or "-"),
        ("Account Number", row["bank_account_number"] or "-"),
        ("IBAN", row["bank_iban"] or "-"),
    ]
    for label, value in data_rows:
        r = t.add_row()
        r.cells[0].text = label
        r.cells[0].paragraphs[0].runs[0].bold = True
        r.cells[1].text = str(value)

    doc.add_paragraph(f"\nGenerated on: {row['generated_on']}")

    buf = BytesIO()
    doc.save(buf)
    buf.seek(0)
    return send_file(buf, as_attachment=True, download_name=f"payslip_{row['emp_name']}_{row['month']}.docx",
                      mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document")


@app.route("/employees")
@login_required
def employees_list():
    q = request.args.get("q", "").strip()
    conn = get_conn()
    if q:
        rows = conn.execute(
            """SELECT * FROM employees WHERE name LIKE ? OR emp_code LIKE ? OR department LIKE ?
               OR designation LIKE ? OR nic_number LIKE ? ORDER BY id DESC""",
            tuple(f"%{q}%" for _ in range(5)),
        ).fetchall()
    else:
        rows = conn.execute("SELECT * FROM employees ORDER BY id DESC").fetchall()
    conn.close()
    return render_template("employees_list.html", employees=rows, q=q)


@app.route("/employees/add", methods=["GET", "POST"])
@login_required
def employee_add():
    if request.method == "POST":
        vals = _employee_form_values()
        if vals is None:
            return redirect(url_for("employee_add"))
        conn = get_conn()
        cur = conn.execute("""
            INSERT INTO employees (emp_code, name, father_name, dob, marital_status, nic_number,
                contact, address, company, department, designation, section, appointment_date,
                leave_date, status, basic_salary, bank_name, bank_account_title, bank_account_number,
                bank_iban, created_by, updated_by, updated_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """, vals + (session["username"], session["username"], str(datetime.now())))
        new_id = cur.lastrowid
        conn.commit()
        _save_uploaded_images(new_id, conn)
        conn.close()
        flash("Employee add ho gaya.", "success")
        return redirect(url_for("employees_list"))
    conn = get_conn()
    departments = conn.execute("SELECT * FROM departments ORDER BY name").fetchall()
    conn.close()
    return render_template("employee_form.html", employee=None, departments=departments)


@app.route("/employees/<int:emp_id>/edit", methods=["GET", "POST"])
@login_required
def employee_edit(emp_id):
    conn = get_conn()
    emp = conn.execute("SELECT * FROM employees WHERE id=?", (emp_id,)).fetchone()
    if not emp:
        conn.close()
        abort(404)
    if request.method == "POST":
        vals = _employee_form_values()
        if vals is None:
            conn.close()
            return redirect(url_for("employee_edit", emp_id=emp_id))
        conn.execute("""
            UPDATE employees SET emp_code=?, name=?, father_name=?, dob=?, marital_status=?, nic_number=?,
                contact=?, address=?, company=?, department=?, designation=?, section=?, appointment_date=?,
                leave_date=?, status=?, basic_salary=?, bank_name=?, bank_account_title=?,
                bank_account_number=?, bank_iban=?, updated_by=?, updated_at=?
            WHERE id=?
        """, vals + (session["username"], str(datetime.now()), emp_id))
        conn.commit()
        _save_uploaded_images(emp_id, conn)
        conn.close()
        flash("Employee update ho gaya.", "success")
        return redirect(url_for("employee_view", emp_id=emp_id))
    departments = conn.execute("SELECT * FROM departments ORDER BY name").fetchall()
    conn.close()
    return render_template("employee_form.html", employee=emp, departments=departments)


@app.route("/employees/<int:emp_id>/delete", methods=["POST"])
@login_required
def employee_delete(emp_id):
    conn = get_conn()
    conn.execute("DELETE FROM employees WHERE id=?", (emp_id,))
    conn.commit()
    conn.close()
    flash("Employee delete ho gaya.", "success")
    return redirect(url_for("employees_list"))


@app.route("/employees/<int:emp_id>")
@login_required
def employee_view(emp_id):
    conn = get_conn()
    emp = conn.execute("SELECT * FROM employees WHERE id=?", (emp_id,)).fetchone()
    if not emp:
        conn.close()
        abort(404)
    attendance_rows = conn.execute(
        "SELECT * FROM attendance WHERE employee_id=? ORDER BY date DESC LIMIT 60", (emp_id,)
    ).fetchall()
    payroll_rows = conn.execute(
        "SELECT * FROM payroll WHERE employee_id=? ORDER BY month DESC", (emp_id,)
    ).fetchall()
    conn.close()
    age = calc_age(emp["dob"]) if emp["dob"] else "N/A"
    return render_template(
        "employee_view.html", emp=emp, attendance_rows=attendance_rows,
        payroll_rows=payroll_rows, age=age
    )


def _employee_form_values():
    name = request.form.get("name", "").strip()
    if not name:
        flash("Name zaroori hai.", "error")
        return None
    try:
        salary = float(request.form.get("basic_salary") or 0)
    except ValueError:
        flash("Basic Salary number honi chahiye.", "error")
        return None
    return (
        request.form.get("emp_code", "").strip(),
        name,
        request.form.get("father_name", "").strip(),
        request.form.get("dob", "").strip(),
        request.form.get("marital_status", "").strip(),
        request.form.get("nic_number", "").strip(),
        request.form.get("contact", "").strip(),
        request.form.get("address", "").strip(),
        request.form.get("company", "").strip(),
        request.form.get("department", "").strip(),
        request.form.get("designation", "").strip(),
        request.form.get("section", "").strip(),
        request.form.get("appointment_date", "").strip(),
        request.form.get("leave_date", "").strip(),
        request.form.get("status", "Active").strip() or "Active",
        salary,
        request.form.get("bank_name", "").strip(),
        request.form.get("bank_account_title", "").strip(),
        request.form.get("bank_account_number", "").strip(),
        request.form.get("bank_iban", "").strip(),
    )


def _save_uploaded_images(emp_id, conn):
    emp_dir = os.path.join(UPLOAD_DIR, f"employee_{emp_id}")
    os.makedirs(emp_dir, exist_ok=True)
    updates = {}
    for field, tag in [("photo", "photo"), ("nic_front", "nic_front"), ("nic_back", "nic_back")]:
        file = request.files.get(field)
        if file and file.filename and allowed_image(file.filename):
            ext = file.filename.rsplit(".", 1)[1].lower()
            fname = f"{tag}.{ext}"
            path = os.path.join(emp_dir, fname)
            file.save(path)
            updates[f"{tag}_path"] = os.path.relpath(path, UPLOAD_DIR)
    if updates:
        set_clause = ", ".join(f"{k}=?" for k in updates)
        conn.execute(f"UPDATE employees SET {set_clause} WHERE id=?", tuple(updates.values()) + (emp_id,))
        conn.commit()


@app.route("/uploads/<path:filename>")
@login_required
def serve_upload(filename):
    return send_from_directory(UPLOAD_DIR, filename)


# ============================================================
#  ATTENDANCE
# ============================================================
@app.route("/attendance", methods=["GET", "POST"])
@login_required
def attendance_page():
    conn = get_conn()
    if request.method == "POST":
        emp_id = request.form.get("employee_id")
        att_date = request.form.get("date", "").strip()
        status = request.form.get("status", "Present")
        try:
            ot = float(request.form.get("overtime_hours") or 0)
        except ValueError:
            ot = 0
        if emp_id and att_date:
            conn.execute(
                "INSERT INTO attendance (employee_id, date, status, overtime_hours, marked_by) VALUES (?,?,?,?,?)",
                (emp_id, att_date, status, ot, session["username"]),
            )
            conn.commit()
            flash("Attendance mark ho gayi.", "success")
        return redirect(url_for("attendance_page", employee_id=emp_id, month=att_date[:7]))

    employees = conn.execute("SELECT id, name FROM employees ORDER BY name").fetchall()
    emp_filter = request.args.get("employee_id", "")
    month_filter = request.args.get("month", str(date.today())[:7])

    query = """SELECT attendance.*, employees.name as emp_name FROM attendance
               JOIN employees ON attendance.employee_id = employees.id WHERE 1=1"""
    params = []
    if emp_filter:
        query += " AND employees.id=?"
        params.append(emp_filter)
    if month_filter:
        query += " AND attendance.date LIKE ?"
        params.append(f"{month_filter}%")
    query += " ORDER BY attendance.date DESC"
    rows = conn.execute(query, params).fetchall()
    conn.close()
    return render_template(
        "attendance.html", employees=employees, rows=rows,
        emp_filter=emp_filter, month_filter=month_filter, today=str(date.today())
    )


# ============================================================
#  PAYROLL
# ============================================================
@app.route("/payroll", methods=["GET", "POST"])
@login_required
def payroll_page():
    conn = get_conn()
    if request.method == "POST":
        emp_id = request.form.get("employee_id")
        month = request.form.get("month", "").strip()
        try:
            deductions = float(request.form.get("deductions") or 0)
        except ValueError:
            deductions = 0

        emp = conn.execute("SELECT basic_salary FROM employees WHERE id=?", (emp_id,)).fetchone()
        if emp and month:
            basic_salary = emp["basic_salary"] or 0
            att_rows = conn.execute(
                "SELECT status, overtime_hours FROM attendance WHERE employee_id=? AND date LIKE ?",
                (emp_id, f"{month}%"),
            ).fetchall()
            present_days = sum(1 for r in att_rows if r["status"] == "Present")
            absent_days = sum(1 for r in att_rows if r["status"] == "Absent")
            leave_days = sum(1 for r in att_rows if r["status"] == "Leave")
            overtime_hours = sum(r["overtime_hours"] or 0 for r in att_rows)

            per_day_rate = basic_salary / WORKING_DAYS_BASIS if WORKING_DAYS_BASIS else 0
            overtime_hourly_rate = (per_day_rate / 8) * 2
            overtime_amount = overtime_hours * overtime_hourly_rate
            gross_salary = (present_days * per_day_rate) + overtime_amount
            net_salary = gross_salary - deductions

            conn.execute("""
                INSERT INTO payroll (employee_id, month, present_days, absent_days, leave_days, overtime_hours,
                    basic_salary, per_day_rate, overtime_hourly_rate, overtime_amount, gross_salary, deductions,
                    net_salary, generated_on, generated_by)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """, (emp_id, month, present_days, absent_days, leave_days, overtime_hours, basic_salary,
                  per_day_rate, overtime_hourly_rate, overtime_amount, gross_salary, deductions, net_salary,
                  str(date.today()), session["username"]))
            conn.commit()
            flash(f"Payroll generate ho gayi. Net Salary: {net_salary:,.2f}", "success")
        conn.close()
        return redirect(url_for("payroll_page"))

    employees = conn.execute("SELECT id, name FROM employees ORDER BY name").fetchall()
    rows = conn.execute("""
        SELECT payroll.*, employees.name as emp_name FROM payroll
        JOIN employees ON payroll.employee_id = employees.id ORDER BY payroll.id DESC
    """).fetchall()
    conn.close()
    return render_template(
        "payroll.html", employees=employees, rows=rows,
        working_days_basis=WORKING_DAYS_BASIS, month_default=str(date.today())[:7]
    )


# ============================================================
#  RECRUITMENT
# ============================================================
STAGES = ["Applied", "Shortlisted", "Interviewed", "Hired", "Rejected"]


@app.route("/recruitment", methods=["GET", "POST"])
@login_required
def recruitment_page():
    conn = get_conn()
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        if name:
            conn.execute(
                "INSERT INTO candidates (name, contact, position, stage, applied_on, notes, created_by) "
                "VALUES (?,?,?,?,?,?,?)",
                (name, request.form.get("contact", "").strip(), request.form.get("position", "").strip(),
                 request.form.get("stage", "Applied"), str(date.today()),
                 request.form.get("notes", "").strip(), session["username"]),
            )
            conn.commit()
            flash("Candidate add ho gaya.", "success")
        conn.close()
        return redirect(url_for("recruitment_page"))

    rows = conn.execute("SELECT * FROM candidates ORDER BY id DESC").fetchall()
    conn.close()
    return render_template("recruitment.html", candidates=rows, stages=STAGES)


@app.route("/recruitment/<int:cid>/stage", methods=["POST"])
@login_required
def recruitment_update_stage(cid):
    stage = request.form.get("stage")
    conn = get_conn()
    conn.execute("UPDATE candidates SET stage=? WHERE id=?", (stage, cid))
    conn.commit()
    conn.close()
    return redirect(url_for("recruitment_page"))


@app.route("/recruitment/<int:cid>/delete", methods=["POST"])
@login_required
def recruitment_delete(cid):
    conn = get_conn()
    conn.execute("DELETE FROM candidates WHERE id=?", (cid,))
    conn.commit()
    conn.close()
    return redirect(url_for("recruitment_page"))


# ============================================================
#  DEPARTMENTS
# ============================================================
@app.route("/departments", methods=["GET", "POST"])
@login_required
def departments_page():
    conn = get_conn()
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        if name:
            try:
                conn.execute("INSERT INTO departments (name) VALUES (?)", (name,))
                conn.commit()
                flash("Department add ho gaya.", "success")
            except sqlite3.IntegrityError:
                flash("Ye department pehle se maujood hai.", "error")
        conn.close()
        return redirect(url_for("departments_page"))

    departments = conn.execute("""
        SELECT departments.*, 
               (SELECT COUNT(*) FROM employees WHERE employees.department = departments.name AND employees.status='Active') as emp_count
        FROM departments ORDER BY departments.name
    """).fetchall()
    conn.close()
    return render_template("departments.html", departments=departments)


@app.route("/departments/<int:dept_id>/delete", methods=["POST"])
@login_required
def department_delete(dept_id):
    conn = get_conn()
    conn.execute("DELETE FROM departments WHERE id=?", (dept_id,))
    conn.commit()
    conn.close()
    flash("Department delete ho gaya.", "success")
    return redirect(url_for("departments_page"))


# ============================================================
#  ROSTER (Shift-wise: Morning / Evening / Night / Off)
# ============================================================
SHIFTS = ["Morning", "Evening", "Night", "Off"]


@app.route("/roster", methods=["GET", "POST"])
@login_required
def roster_page():
    conn = get_conn()
    if request.method == "POST":
        emp_id = request.form.get("employee_id")
        r_date = request.form.get("date", "").strip()
        shift = request.form.get("shift", "Morning")
        if emp_id and r_date:
            conn.execute("""
                INSERT INTO roster (employee_id, date, shift, assigned_by) VALUES (?,?,?,?)
                ON CONFLICT(employee_id, date) DO UPDATE SET shift=excluded.shift, assigned_by=excluded.assigned_by
            """, (emp_id, r_date, shift, session["username"]))
            conn.commit()
            flash("Roster update ho gaya.", "success")
        conn.close()
        return redirect(url_for("roster_page", week_start=request.form.get("week_start", "")))

    employees = conn.execute("SELECT id, name, department FROM employees WHERE status='Active' ORDER BY name").fetchall()

    # Determine the week to display (Mon-Sun) based on ?week_start=YYYY-MM-DD, default = this week's Monday
    week_start_str = request.args.get("week_start", "")
    if week_start_str:
        try:
            y, m, d = map(int, week_start_str.split("-"))
            week_start = date(y, m, d)
        except Exception:
            week_start = date.today()
    else:
        week_start = date.today()
        week_start = week_start.fromordinal(week_start.toordinal() - week_start.weekday())  # Monday

    week_dates = [week_start.fromordinal(week_start.toordinal() + i) for i in range(7)]
    prev_week = week_start.fromordinal(week_start.toordinal() - 7)
    next_week = week_start.fromordinal(week_start.toordinal() + 7)

    rows = conn.execute(
        "SELECT * FROM roster WHERE date BETWEEN ? AND ?",
        (str(week_dates[0]), str(week_dates[-1])),
    ).fetchall()
    conn.close()

    # Build lookup: {(employee_id, date): shift}
    roster_map = {(r["employee_id"], r["date"]): r["shift"] for r in rows}

    return render_template(
        "roster.html", employees=employees, week_dates=week_dates, roster_map=roster_map,
        shifts=SHIFTS, week_start=week_start, prev_week=prev_week, next_week=next_week,
        today=str(date.today())
    )


# ============================================================
#  SALARY INCREMENT
# ============================================================
@app.route("/employees/<int:emp_id>/salary-increment", methods=["GET", "POST"])
@login_required
def salary_increment(emp_id):
    conn = get_conn()
    emp = conn.execute("SELECT * FROM employees WHERE id=?", (emp_id,)).fetchone()
    if not emp:
        conn.close()
        abort(404)

    if request.method == "POST":
        try:
            new_salary = float(request.form.get("new_salary"))
        except (ValueError, TypeError):
            flash("New Salary number honi chahiye.", "error")
            conn.close()
            return redirect(url_for("salary_increment", emp_id=emp_id))

        effective_date = request.form.get("effective_date", "").strip() or str(date.today())
        reason = request.form.get("reason", "").strip()
        old_salary = emp["basic_salary"] or 0

        conn.execute("""
            INSERT INTO salary_history (employee_id, old_salary, new_salary, effective_date, reason,
                updated_by, updated_at) VALUES (?,?,?,?,?,?,?)
        """, (emp_id, old_salary, new_salary, effective_date, reason, session["username"], str(datetime.now())))
        conn.execute("UPDATE employees SET basic_salary=? WHERE id=?", (new_salary, emp_id))
        conn.commit()
        conn.close()
        flash(f"Salary update ho gayi: {old_salary:,.2f} -> {new_salary:,.2f}", "success")
        return redirect(url_for("employee_view", emp_id=emp_id))

    history = conn.execute(
        "SELECT * FROM salary_history WHERE employee_id=? ORDER BY effective_date DESC", (emp_id,)
    ).fetchall()
    conn.close()
    return render_template("salary_increment.html", emp=emp, history=history)


# ============================================================
#  AI ASSISTANT (Chatbot - answers questions using live DB data)
# ============================================================
def _gather_ai_context(question):
    """Build a compact, relevant context string from the database based on the question."""
    conn = get_conn()
    q_lower = question.lower()

    lines = []

    # Overall stats (always included, cheap)
    total_active = conn.execute("SELECT COUNT(*) FROM employees WHERE status='Active'").fetchone()[0]
    total_left = conn.execute("SELECT COUNT(*) FROM employees WHERE status='Left'").fetchone()[0]
    today_present = conn.execute(
        "SELECT COUNT(*) FROM attendance WHERE date=? AND status='Present'", (str(date.today()),)
    ).fetchone()[0]
    lines.append(f"Company-wide stats: {total_active} active employees, {total_left} left/resigned, "
                 f"{today_present} marked Present today ({date.today()}).")

    # Try to find a specific employee mentioned by name in the question
    all_emps = conn.execute("SELECT id, name FROM employees").fetchall()
    matched_emp = None
    for e in all_emps:
        if e["name"] and e["name"].lower() in q_lower:
            matched_emp = e
            break

    if matched_emp:
        emp = conn.execute("SELECT * FROM employees WHERE id=?", (matched_emp["id"],)).fetchone()
        lines.append(
            f"\nEmployee record for {emp['name']}: Code={emp['emp_code']}, Father Name={emp['father_name']}, "
            f"DOB={emp['dob']}, Department={emp['department']}, Designation={emp['designation']}, "
            f"Section={emp['section']}, Status={emp['status']}, Appointment Date={emp['appointment_date']}, "
            f"Leave Date={emp['leave_date']}, Basic Salary={emp['basic_salary']}."
        )
        att = conn.execute(
            "SELECT date, status, overtime_hours FROM attendance WHERE employee_id=? ORDER BY date DESC LIMIT 30",
            (matched_emp["id"],),
        ).fetchall()
        if att:
            att_lines = "; ".join(f"{a['date']}={a['status']}(OT {a['overtime_hours']}h)" for a in att)
            lines.append(f"Recent attendance (last 30 records) for {emp['name']}: {att_lines}")
        pay = conn.execute(
            "SELECT month, present_days, absent_days, overtime_hours, gross_salary, deductions, net_salary "
            "FROM payroll WHERE employee_id=? ORDER BY month DESC LIMIT 6",
            (matched_emp["id"],),
        ).fetchall()
        if pay:
            pay_lines = "; ".join(
                f"{p['month']}: present={p['present_days']}, absent={p['absent_days']}, "
                f"OT={p['overtime_hours']}h, gross={p['gross_salary']}, net={p['net_salary']}" for p in pay
            )
            lines.append(f"Recent payroll history for {emp['name']}: {pay_lines}")
        sal_hist = conn.execute(
            "SELECT old_salary, new_salary, effective_date, reason FROM salary_history WHERE employee_id=? "
            "ORDER BY effective_date DESC", (matched_emp["id"],)
        ).fetchall()
        if sal_hist:
            sh_lines = "; ".join(
                f"{s['effective_date']}: {s['old_salary']} -> {s['new_salary']} ({s['reason'] or 'no reason given'})"
                for s in sal_hist
            )
            lines.append(f"Salary increment history for {emp['name']}: {sh_lines}")
    else:
        # No specific employee matched - include department-wise headcount and full employee list summary
        dept_rows = conn.execute(
            "SELECT department, COUNT(*) as cnt FROM employees WHERE status='Active' GROUP BY department"
        ).fetchall()
        if dept_rows:
            dept_lines = "; ".join(f"{d['department'] or 'Unassigned'}={d['cnt']}" for d in dept_rows)
            lines.append(f"Active employee count by department: {dept_lines}")

        emp_list = conn.execute(
            "SELECT name, department, designation, status FROM employees ORDER BY name LIMIT 100"
        ).fetchall()
        emp_lines = "; ".join(
            f"{e['name']} ({e['department'] or '-'}, {e['designation'] or '-'}, {e['status']})" for e in emp_list
        )
        lines.append(f"Employee list: {emp_lines}")

        pending_candidates = conn.execute(
            "SELECT name, position, stage FROM candidates WHERE stage NOT IN ('Hired','Rejected')"
        ).fetchall()
        if pending_candidates:
            cand_lines = "; ".join(f"{c['name']} ({c['position'] or '-'}, stage={c['stage']})" for c in pending_candidates)
            lines.append(f"Candidates currently in recruitment pipeline: {cand_lines}")

    conn.close()
    return "\n".join(lines)


@app.route("/ai-assistant", methods=["GET", "POST"])
@login_required
def ai_assistant_page():
    answer = None
    question = ""
    error = None

    if request.method == "POST":
        question = request.form.get("question", "").strip()
        api_key = os.environ.get("ANTHROPIC_API_KEY", "")

        if not ANTHROPIC_OK:
            error = "AI library install nahi hai. Server par ye chalayein: pip install anthropic"
        elif not api_key:
            error = ("AI Assistant use karne ke liye ANTHROPIC_API_KEY environment variable set karna zaroori hai. "
                      "DEPLOY.txt mein instructions hain.")
        elif not question:
            error = "Pehle koi sawal likhein."
        else:
            try:
                context = _gather_ai_context(question)
                client = anthropic.Anthropic(api_key=api_key)
                response = client.messages.create(
                    model="claude-sonnet-4-6",
                    max_tokens=600,
                    system=(
                        "You are an HR data assistant. Answer the user's question ONLY using the HR data "
                        "context provided below. If the data needed isn't in the context, say so clearly rather "
                        "than guessing. Keep answers concise and in the same language style (Roman Urdu/English "
                        "mix is fine) as the question. Never invent employee data that isn't given to you.\n\n"
                        f"HR DATA CONTEXT:\n{context}"
                    ),
                    messages=[{"role": "user", "content": question}],
                )
                answer = "".join(block.text for block in response.content if hasattr(block, "text"))
            except Exception as e:
                error = f"AI se jawab lete waqt error aayi: {e}"

    return render_template("ai_assistant.html", answer=answer, question=question, error=error)



@app.route("/users", methods=["GET", "POST"])
@admin_required
def users_page():
    conn = get_conn()
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        full_name = request.form.get("full_name", "").strip()
        email = request.form.get("email", "").strip()
        role = request.form.get("role", "HR Staff")
        if username and password:
            try:
                conn.execute(
                    "INSERT INTO users (username, password_hash, full_name, email, role, created_at) VALUES (?,?,?,?,?,?)",
                    (username, generate_password_hash(password), full_name, email, role, str(datetime.now())),
                )
                conn.commit()
                flash("User add ho gaya.", "success")
            except sqlite3.IntegrityError:
                flash("Ye username pehle se maujood hai.", "error")
        conn.close()
        return redirect(url_for("users_page"))

    rows = conn.execute("SELECT id, username, full_name, email, role, created_at FROM users ORDER BY id").fetchall()
    conn.close()
    return render_template("users.html", users=rows, smtp_configured=smtp_configured())


@app.route("/users/<int:uid>/reset-password", methods=["POST"])
@admin_required
def user_reset_password(uid):
    new_password = request.form.get("new_password", "").strip()
    conn = get_conn()
    user = conn.execute("SELECT * FROM users WHERE id=?", (uid,)).fetchone()
    if not user:
        conn.close()
        abort(404)
    if not new_password:
        new_password = secrets.token_urlsafe(6)  # auto-generate a temporary password
    conn.execute("UPDATE users SET password_hash=? WHERE id=?", (generate_password_hash(new_password), uid))
    conn.commit()
    conn.close()
    flash(f"Password reset ho gaya for {user['username']}. Naya (temporary) password: {new_password}", "success")
    return redirect(url_for("users_page"))


@app.route("/users/<int:uid>/delete", methods=["POST"])
@admin_required
def user_delete(uid):
    if uid == session.get("user_id"):
        flash("Aap apna khud ka account delete nahi kar sakte.", "error")
        return redirect(url_for("users_page"))
    conn = get_conn()
    conn.execute("DELETE FROM users WHERE id=?", (uid,))
    conn.commit()
    conn.close()
    flash("User delete ho gaya.", "success")
    return redirect(url_for("users_page"))


@app.route("/change-password", methods=["GET", "POST"])
@login_required
def change_password():
    if request.method == "POST":
        current = request.form.get("current_password", "")
        new = request.form.get("new_password", "")
        conn = get_conn()
        user = conn.execute("SELECT * FROM users WHERE id=?", (session["user_id"],)).fetchone()
        if user and check_password_hash(user["password_hash"], current) and new:
            conn.execute("UPDATE users SET password_hash=? WHERE id=?",
                         (generate_password_hash(new), session["user_id"]))
            conn.commit()
            flash("Password change ho gaya.", "success")
            conn.close()
            return redirect(url_for("dashboard"))
        flash("Current password ghalat hai.", "error")
        conn.close()
    return render_template("change_password.html")


# ============================================================
#  PDF GENERATION
# ============================================================
def _styles():
    ss = getSampleStyleSheet()
    ss.add(ParagraphStyle(name="HRTitle", fontSize=16, alignment=TA_CENTER, spaceAfter=10, fontName="Helvetica-Bold"))
    ss.add(ParagraphStyle(name="HRSub", fontSize=10, alignment=TA_CENTER, textColor=colors.grey, spaceAfter=14))
    ss.add(ParagraphStyle(name="HRHeading", fontSize=12, fontName="Helvetica-Bold", spaceBefore=14, spaceAfter=6,
                           textColor=colors.HexColor("#2c3e50")))
    ss.add(ParagraphStyle(name="HRBody", fontSize=10, alignment=TA_JUSTIFY, leading=15))
    return ss


def _emp_info_table(emp):
    age = calc_age(emp["dob"]) if emp["dob"] else "N/A"
    data = [
        ["Employee Code:", emp["emp_code"] or "-", "Status:", emp["status"]],
        ["Name:", emp["name"], "Father Name:", emp["father_name"] or "-"],
        ["Date of Birth:", emp["dob"] or "-", "Age:", str(age)],
        ["Marital Status:", emp["marital_status"] or "-", "NIC Number:", emp["nic_number"] or "-"],
        ["Contact:", emp["contact"] or "-", "Address:", emp["address"] or "-"],
        ["Company:", emp["company"] or "-", "Department:", emp["department"] or "-"],
        ["Designation:", emp["designation"] or "-", "Section:", emp["section"] or "-"],
        ["Appointment Date:", emp["appointment_date"] or "-", "Leave Date:", emp["leave_date"] or "-"],
        ["Basic Salary:", f"{emp['basic_salary']:,.2f}" if emp["basic_salary"] else "-", "", ""],
    ]
    t = Table(data, colWidths=[95, 150, 95, 130])
    t.setStyle(TableStyle([
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
        ("FONTNAME", (2, 0), (2, -1), "Helvetica-Bold"),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#cccccc")),
        ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#f2f2f2")),
        ("BACKGROUND", (2, 0), (2, -1), colors.HexColor("#f2f2f2")),
    ]))
    return t


def _abs_path(rel_path):
    if not rel_path:
        return None
    p = os.path.join(UPLOAD_DIR, rel_path)
    return p if os.path.exists(p) else None


@app.route("/employees/<int:emp_id>/pdf/appointment_letter")
@login_required
def pdf_appointment_letter(emp_id):
    conn = get_conn()
    emp = conn.execute("SELECT * FROM employees WHERE id=?", (emp_id,)).fetchone()
    conn.close()
    if not emp:
        abort(404)
    path = os.path.join(PDF_DIR, f"appointment_letter_{emp_id}.pdf")
    doc = SimpleDocTemplate(path, pagesize=A4, topMargin=25 * mm, bottomMargin=20 * mm)
    ss = _styles()
    story = [
        Paragraph(emp["company"] or "COMPANY NAME", ss["HRTitle"]),
        Paragraph("Appointment Letter", ss["HRSub"]),
        Paragraph(f"Date: {emp['appointment_date'] or str(date.today())}", ss["HRBody"]),
        Spacer(1, 10),
    ]
    body = (
        f"Dear {emp['name']} S/D/O {emp['father_name'] or '-'},<br/><br/>"
        f"We are pleased to confirm your appointment with {emp['company'] or 'the company'} as "
        f"<b>{emp['designation'] or '-'}</b> in the <b>{emp['department'] or '-'}</b> department "
        f"({emp['section'] or '-'} section), with effect from <b>{emp['appointment_date'] or '-'}</b>.<br/><br/>"
        f"Your NIC number on record is <b>{emp['nic_number'] or '-'}</b>. Your monthly basic salary "
        f"has been fixed at <b>{emp['basic_salary']:,.2f}</b>, subject to the company's attendance and "
        f"leave policy. Salary is calculated on a 26-day basis, and any overtime worked will be "
        f"compensated at double the standard hourly rate.<br/><br/>"
        f"You are required to abide by all company rules, regulations, and codes of conduct "
        f"during your employment.<br/><br/>"
        f"We welcome you to the team and wish you a successful career with us."
    )
    story.append(Paragraph(body, ss["HRBody"]))
    story.append(Spacer(1, 40))
    story.append(Paragraph("_____________________________", ss["HRBody"]))
    story.append(Paragraph("Authorized Signature (HR Department)", ss["HRBody"]))
    doc.build(story)
    return send_file(path, as_attachment=False)


@app.route("/employees/<int:emp_id>/pdf/taaruf_nama")
@login_required
def pdf_taaruf_nama(emp_id):
    conn = get_conn()
    emp = conn.execute("SELECT * FROM employees WHERE id=?", (emp_id,)).fetchone()
    conn.close()
    if not emp:
        abort(404)
    path = os.path.join(PDF_DIR, f"taaruf_nama_{emp_id}.pdf")
    doc = SimpleDocTemplate(path, pagesize=A4, topMargin=25 * mm, bottomMargin=20 * mm)
    ss = _styles()
    story = [
        Paragraph(emp["company"] or "COMPANY NAME", ss["HRTitle"]),
        Paragraph("Introduction Letter (Taaruf Nama)", ss["HRSub"]),
    ]
    photo = _abs_path(emp["photo_path"])
    if photo:
        try:
            story.append(RLImage(photo, width=35 * mm, height=40 * mm))
            story.append(Spacer(1, 10))
        except Exception:
            pass
    body = (
        f"This is to certify that <b>{emp['name']}</b>, S/D/O <b>{emp['father_name'] or '-'}</b>, "
        f"holding NIC number <b>{emp['nic_number'] or '-'}</b>, is a bonafide employee of "
        f"<b>{emp['company'] or 'the company'}</b>, working as <b>{emp['designation'] or '-'}</b> in the "
        f"<b>{emp['department'] or '-'}</b> department ({emp['section'] or '-'}) since "
        f"<b>{emp['appointment_date'] or '-'}</b>.<br/><br/>"
        f"This letter is issued for identification and verification purposes."
    )
    story.append(Paragraph(body, ss["HRBody"]))
    story.append(Spacer(1, 40))
    story.append(Paragraph("_____________________________", ss["HRBody"]))
    story.append(Paragraph("Authorized Signature (HR Department)", ss["HRBody"]))
    doc.build(story)
    return send_file(path, as_attachment=False)


@app.route("/employees/<int:emp_id>/pdf/personal_file")
@login_required
def pdf_personal_file(emp_id):
    conn = get_conn()
    emp = conn.execute("SELECT * FROM employees WHERE id=?", (emp_id,)).fetchone()
    attendance_rows = conn.execute(
        "SELECT date, status, overtime_hours FROM attendance WHERE employee_id=? ORDER BY date", (emp_id,)
    ).fetchall()
    payroll_rows = conn.execute(
        "SELECT month, present_days, absent_days, overtime_hours, gross_salary, deductions, net_salary "
        "FROM payroll WHERE employee_id=? ORDER BY month", (emp_id,)
    ).fetchall()
    conn.close()
    if not emp:
        abort(404)

    path = os.path.join(PDF_DIR, f"personal_file_{emp_id}.pdf")
    doc = SimpleDocTemplate(path, pagesize=A4, topMargin=20 * mm, bottomMargin=18 * mm)
    ss = _styles()
    story = [
        Paragraph(emp["company"] or "COMPANY NAME", ss["HRTitle"]),
        Paragraph(f"Employee Personal File — {emp['name']}", ss["HRSub"]),
    ]

    photo = _abs_path(emp["photo_path"])
    if photo:
        try:
            story.append(RLImage(photo, width=30 * mm, height=35 * mm))
            story.append(Spacer(1, 8))
        except Exception:
            pass

    story.append(Paragraph("1. Personal & Employment Details", ss["HRHeading"]))
    story.append(_emp_info_table(emp))

    story.append(Paragraph("2. National Identity Card (NIC)", ss["HRHeading"]))
    nic_imgs = []
    for rel_path in [emp["nic_front_path"], emp["nic_back_path"]]:
        p = _abs_path(rel_path)
        if p:
            try:
                nic_imgs.append(RLImage(p, width=75 * mm, height=48 * mm))
            except Exception:
                pass
    if nic_imgs:
        story.append(Table([nic_imgs]))
    else:
        story.append(Paragraph("NIC images not uploaded.", ss["HRBody"]))

    story.append(PageBreak())
    story.append(Paragraph("3. Appointment Letter", ss["HRHeading"]))
    story.append(Paragraph(
        f"This confirms the appointment of <b>{emp['name']}</b> as <b>{emp['designation'] or '-'}</b> in the "
        f"<b>{emp['department'] or '-'}</b> department ({emp['section'] or '-'}), effective "
        f"<b>{emp['appointment_date'] or '-'}</b>, at a monthly basic salary of "
        f"<b>{emp['basic_salary']:,.2f}</b> (26-day basis, overtime at double rate).",
        ss["HRBody"]))

    story.append(Paragraph("4. Introduction Letter (Taaruf Nama)", ss["HRHeading"]))
    story.append(Paragraph(
        f"This certifies that <b>{emp['name']}</b> S/D/O <b>{emp['father_name'] or '-'}</b>, NIC "
        f"<b>{emp['nic_number'] or '-'}</b>, is a bonafide employee of <b>{emp['company'] or '-'}</b>.",
        ss["HRBody"]))

    story.append(Paragraph("5. Age Verification", ss["HRHeading"]))
    age = calc_age(emp["dob"]) if emp["dob"] else "N/A"
    story.append(Paragraph(
        f"Date of Birth: <b>{emp['dob'] or '-'}</b> &nbsp;&nbsp; Calculated Age: <b>{age} years</b> "
        f"(as verified against NIC record).", ss["HRBody"]))

    story.append(PageBreak())
    story.append(Paragraph("6. Attendance Record", ss["HRHeading"]))
    if attendance_rows:
        data = [["Date", "Status", "Overtime (hrs)"]] + [[r["date"], r["status"], str(r["overtime_hours"])]
                                                            for r in attendance_rows]
        t = Table(data, colWidths=[150, 150, 120])
        t.setStyle(TableStyle([
            ("FONTSIZE", (0, 0), (-1, -1), 8),
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2c3e50")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#cccccc")),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ]))
        story.append(t)
    else:
        story.append(Paragraph("No attendance records found.", ss["HRBody"]))

    story.append(Spacer(1, 16))
    story.append(Paragraph("7. Payroll History", ss["HRHeading"]))
    if payroll_rows:
        data = [["Month", "Present", "Absent", "OT (hrs)", "Gross", "Deductions", "Net Salary"]]
        for r in payroll_rows:
            data.append([r["month"], str(r["present_days"]), str(r["absent_days"]), str(r["overtime_hours"]),
                         f"{r['gross_salary']:,.2f}", f"{r['deductions']:,.2f}", f"{r['net_salary']:,.2f}"])
        t = Table(data, colWidths=[60, 50, 50, 55, 75, 75, 80])
        t.setStyle(TableStyle([
            ("FONTSIZE", (0, 0), (-1, -1), 8),
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2c3e50")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#cccccc")),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ]))
        story.append(t)
    else:
        story.append(Paragraph("No payroll records found.", ss["HRBody"]))

    story.append(Spacer(1, 30))
    story.append(Paragraph(f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M')} — For Audit Purposes",
                            ss["HRSub"]))

    doc.build(story)
    return send_file(path, as_attachment=False)


@app.route("/attendance/pdf")
@login_required
def pdf_attendance_report():
    emp_id = request.args.get("employee_id")
    month = request.args.get("month", "")
    conn = get_conn()
    emp = conn.execute("SELECT name FROM employees WHERE id=?", (emp_id,)).fetchone()
    rows = conn.execute(
        "SELECT date, status, overtime_hours FROM attendance WHERE employee_id=? AND date LIKE ? ORDER BY date",
        (emp_id, f"{month}%"),
    ).fetchall()
    conn.close()
    if not emp:
        abort(404)

    path = os.path.join(PDF_DIR, f"attendance_{emp['name'].replace(' ', '_')}_{month}.pdf")
    doc = SimpleDocTemplate(path, pagesize=A4, topMargin=20 * mm)
    ss = _styles()
    story = [
        Paragraph("Attendance Report", ss["HRTitle"]),
        Paragraph(f"Employee: {emp['name']} | Month: {month}", ss["HRSub"]),
    ]
    data = [["Date", "Status", "Overtime (hrs)"]] + [[r["date"], r["status"], str(r["overtime_hours"])]
                                                        for r in rows]
    t = Table(data, colWidths=[160, 160, 120])
    t.setStyle(TableStyle([
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2c3e50")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#cccccc")),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
    ]))
    story.append(t)
    doc.build(story)
    return send_file(path, as_attachment=False)


@app.route("/payroll/<int:payroll_id>/pdf")
@login_required
def pdf_payslip(payroll_id):
    conn = get_conn()
    row = conn.execute("""
        SELECT payroll.*, employees.name as emp_name FROM payroll
        JOIN employees ON payroll.employee_id = employees.id WHERE payroll.id=?
    """, (payroll_id,)).fetchone()
    conn.close()
    if not row:
        abort(404)

    path = os.path.join(PDF_DIR, f"payslip_{row['emp_name'].replace(' ', '_')}_{row['month']}.pdf")
    doc = SimpleDocTemplate(path, pagesize=A4, topMargin=25 * mm)
    ss = _styles()
    story = [
        Paragraph("Salary Slip", ss["HRTitle"]),
        Paragraph(f"Employee: {row['emp_name']} | Month: {row['month']}", ss["HRSub"]),
    ]
    data = [
        ["Basic Salary", f"{row['basic_salary']:,.2f}"],
        ["Per Day Rate (Salary/26)", f"{row['per_day_rate']:,.2f}"],
        ["Present Days", str(row["present_days"])],
        ["Absent Days", str(row["absent_days"])],
        ["Leave Days", str(row["leave_days"])],
        ["Overtime Hours", str(row["overtime_hours"])],
        ["Overtime Rate (double, per hour)", f"{row['overtime_hourly_rate']:,.2f}"],
        ["Overtime Amount", f"{row['overtime_amount']:,.2f}"],
        ["Gross Salary", f"{row['gross_salary']:,.2f}"],
        ["Deductions", f"{row['deductions']:,.2f}"],
        ["NET SALARY", f"{row['net_salary']:,.2f}"],
    ]
    t = Table(data, colWidths=[260, 180])
    t.setStyle(TableStyle([
        ("FONTSIZE", (0, 0), (-1, -1), 10),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#cccccc")),
        ("BACKGROUND", (0, -1), (-1, -1), colors.HexColor("#2c3e50")),
        ("TEXTCOLOR", (0, -1), (-1, -1), colors.white),
        ("FONTNAME", (0, -1), (-1, -1), "Helvetica-Bold"),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
    ]))
    story.append(t)
    story.append(Spacer(1, 10))
    story.append(Paragraph(f"Generated on: {row['generated_on']}", ss["HRSub"]))
    doc.build(story)
    return send_file(path, as_attachment=False)


# ============================================================
#  ENTRY POINT
# ============================================================
init_db()

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)
